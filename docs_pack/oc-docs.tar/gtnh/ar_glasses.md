# AR Glasses

- **name**: AR Glasses
- **image**: ARGlasses.png
- **source**: [OCGlasses](https://github.com/GTNewHorizons/OCGlasses/blob/806d700962ea82de00a6eb7078f0858dfcd03512/src/main/java/com/bymarcin/openglasses/OpenGlasses.java)
- **tier**: HV
- **durability**: Infinite
- **energy**: N/A
- **voltage**: N/A

**AR Glasses** are an add-on to [OpenComputers](open_computers.md) (OC) for displaying shapes, information, and widgets on the player's HUD. The most popular application is displaying Lapotronic Supercapacitor (LSC) data in real-time. See [OC Power Display](power_display.md) for more information on setting that up.

## Getting Started

AR Glasses must first be linked to a glasses terminal to do anything. Right-click the terminal with the AR Glasses in hand to save its coordinates, dimension, and key. These values should appear in the tooltip of the AR Glasses to inform the player that a successful link has been created.

Next, connect the glasses terminal to a computer with OC cables. Open up a new script and add the following to grab the glasses object.

```lua
local component = require('component')
local glasses   = component.glasses
```

If there are multiple glasses terminal on the same network, use the following to grab all the glasses objects and put them in a table.

```lua
local component = require('component')
local glasses   = {}

for addr in component.list('glasses') do
  table.insert(glasses, component.proxy(component.get(addr)))
end
```

Lastly, equip the AR glasses in either the helmet slot, a bauble slot, or the Tinker's mask slot.

## Methods

The following are the available methods native to AR Glasses. Note that the power consumption of the glasses terminal scales with the number of widgets.

```lua
---Lists the name of all the players currently wearing AR glasses linked to the terminal and are online.
---@return string
function glasses.getBindPlayers() end

---Gets the number of instantiated widgets.
---@return integer
function glasses.getObjectCount() end

---Generates a new UUID
---@return integer
function glasses.newUniqueKey() end

---Removes the widget with the corresponding id. Returns true if successful.
---@param widgetId integer
---@return boolean
function glasses.removeObject(widgetId) end

---Removes all widgets.
function glasses.removeAll() end

--- ===== 2D =====

---Adds a new dot widget to the render surface.
---@return Dot2D
function glasses.addDot() end

---Adds a new triangle widget to the surface.
---@return Triangle2D
function glasses.addTriangle() end

---Adds a new rectangle widget to the render surface.
---@return Rect2D
function glasses.addRect() end

---Adds a new quad widget to the surface.
---@return Quad2D
function glasses.addQuad() end

---Adds a new text label widget to the surface.
---@return Text2D
function glasses.addTextLabel() end

---Adds a new item widget to the surface.
---@return ItemIcon2D
function glasses.addItem() end

--- ===== 3D =====

---Adds a new 3D dot widget to the world.
---@return Dot3D
function glasses.addDot3D() end

---Adds a new 3D line widget to the world.
---@return Line3D
function glasses.addLine3D() end

---Adds a new 3D triangle widget to the world.
---@return Triangle3D
function glasses.addTriangle3D() end

---Adds a new cube widget to the world.
---@return Cube3D
function glasses.addCube3D() end

---Adds a new 3D quad widget to the world.
---@return Quad3D
function glasses.addQuad3D() end

---Adds a new floating text widget to the world.
---@return Text3D
function glasses.addFloatingText() end

--- Credits: Navatusein
```

> Source: [GTNH Wiki](https://gtnh.miraheze.org/wiki/AR_Glasses)
