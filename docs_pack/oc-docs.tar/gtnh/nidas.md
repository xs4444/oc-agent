# NIDAS

NIDAS is an acronym for **N**etworked **I**nformation **D**isplay & **A**utomation **S**oftware. It's an OpenComputers HUD program written by Sampsa, capable of running in-game as a control for power networks, fluid/power monitoring, ore processing, notification of [Maintenance](https://gtnh.miraheze.org/wiki/Multiblock_Machines#maintenance-hatch) issues, AE2 auto-stocking and infusion automation.

The source code for NIDAS can be found on [GitHub](https://github.com/S4mpsa/NIDAS), and its documentation can be found [here](https://github.com/S4mpsa/NIDAS/wiki). Progress into late [HV](high_voltage_(hv).md) tier, preferably [EV](extreme_voltage_(ev).md), is required to setup NIDAS as T3 components use Titanium.

Most people set up NIDAS when they unlock the [Lapotronic Supercapacitor](https://gtnh.miraheze.org/wiki/Lapotronic_Supercapacitor).



^ NIDAS HUD module displaying various information.
- Total Energy in Energy Storage
- Energy input/output
- Minecraft world time, day and year
- Real time

> 💡 **New to OpenComputers?** Look in the Quest Book under the "Advanced Automation" tab to get started.

Below is a guide to installing NIDAS, however there is also a well made Youtube tutorial that will guide you through a basic setup: [NIDAS Youtube Tutorial](https://www.youtube.com/watch?v=nlG8OX8jErs)

If power display is the only desired feature then an alternative is using the [Open Computers Power Display](power_display.md).

### Setting up a NIDAS computer/server

NIDAS requires a high-end OpenComputers computer/server to run, with the specs listed below. It can also be configured as a main/local server setup with multiple machines for larger bases. In that case only the local devices will need component busses.

Here's a list of what you'll need:

- Blocks
  - Computer Case (Tier 3)
  - Screen (Tier 3)
  - Keyboard
  - Power converter

- Components
  - EEPROM (Lua BIOS)
  - OpenOS floppy
  - Central Processing Unit (CPU) (Tier 3)
  - Graphics Card (Tier 3)
  - Memory (Tier 3.5)
  - Internet Card
  - Wireless Network Card (Tier 2)
  - Hard Disk Drive (minimum Tier 2, Tier 3 recommended)
  - Component Bus (Tier 3) | Possibly multiple if connecting lots of machines

To setup a server, take the following steps:

- Place the computer case, screen & power converter together
- Place all components inside the case
- Supply power to the power converter
- Install OpenOS
- Install NIDAS (copy the following command into the shell and press enter).

```bash
wget -f https://raw.githubusercontent.com/S4mpsa/NIDAS/master/setup.lua && setup
```

After this basic setup, the computer will have NIDAS installed. You can now click on "Primary Server" > "Activate" to configure this particular computer to run as the primary server for your NIDAS system (don't forget to click on "Save" to apply your changes). You can setup more systems following the same steps (but without activating the "Primary Server" module), which will then also be a part of the NIDAS network.

It's also recommend to enable "Autorun" in the settings at the bottom (don't forget to save!).

The primary server is also the server you will want to connect to your primary power storage. You can do so by running a length of OpenComputer cable to your [Lapotronic Supercapacitor](https://gtnh.miraheze.org/wiki/Lapotronic_Supercapacitor) (or other choice of power storage) and set down an Adapter next to it connected to the cable line. (The Adapter has to touch the LSC controller, the cable doesn't have to.)

You can then go to "Primary Server" > "Configure" and select your power storage in the options in "Power Capacitor" (keep in mind that you can use OC's analyzer to get the address of any device). Don't forget to click on "Save Configuration" afterwards.

Now the server is able to read information from this connect power storage, various other modules will use this information. Read further down below how to use these.

### Setting up the HUD module

Craft a Glasses Terminal and a pair of AR Glasses, set down the terminal connected to the computer (range on it is infinite, don't worry), right click the glasses on the terminal (there won't be any immediate feedback but the glasses' tooltip will have updated).

You can now equip the AR glasses either as a helmet or in an extra-slot such as baubles necklace slot or Tinker's Construct glasses slot.

Now go into the server and active the HUD module, and then open it's config page. Select the UUID of your glasses in the list and select the HUD elements you want, there are some configuration options to keep in mind:

- Check what your GUI scale is set to in your options and set the scale accordingly (1=small, 2=normal, 3=large, 4=auto).
- Check your screen's resolution; if you're playing in fullscreen it's easy, but if you're in windowed then you might have to subtract a bit from your Y resolution.
- If you care about the time display, check your time zone's UTC offset and set it accordingly.

Don't forget to save your configuration! Afterwards, reboot to ensure everything works as expected.

Enjoy your shiny new HUD overlay!

> Source: [GTNH Wiki](https://gtnh.miraheze.org/wiki/NIDAS)
