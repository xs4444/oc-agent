# GTNH Cross-Mod Integration

OpenComputers (OC) integrates with many GTNH mods through **Adapter** blocks, component drivers, and P2P tunnels. This page is the index for per-mod integration documents, plus the shared concepts.

## Mod Integration Index

| Mod | Key Integration |
| --- | --- |
| [GregTech](mods/gregtech.md) | gt_machine / LSC / gt_energyContainer / GT-Data Server, BHC/SLAM/Bacterial Vat 自动化 |
| [Applied Energistics 2](mods/ae2.md) | me_controller / me_interface, P2P tunnel (COMPUTER_MESSAGE), 全部驱动 |
| [Draconic Evolution](mods/draconic_evolution.md) | draconic_reactor 反应堆监控与安全关停 |
| [Stargate / SGCraft](mods/sgcraft.md) | stargate 组件:拨号、虹膜、能量、报文转发 |
| [Logistics Pipes](mods/logistics_pipes.md) | CC QuickSort / CC ItemSink / CC Control Upgrade |
| [Thaumcraft](mods/thaumcraft.md) | aspect_container / infusion_matrix, 内置驱动 |
| [Forge of the Gods](mods/forge_of_the_gods.md) | OC + AE2 自动化方案 |
| [OCGlasses (AR Glasses)](mods/ocglasses.md) | glasses HUD 组件(2D/3D 部件) |
| [Computronics](mods/computronics.md) | 40+ 驱动:GT/EnderIO/Railcraft/AE2, 卡片与板件 |
| [OpenPrinter](mods/openprinter.md) | printer 组件:12 方法,打印/扫描/名牌 |
| [OpenSecurity](mods/opensecurity.md) | 11 组件:报警/炮塔/键盘锁/RFID/门控,61 方法 |
| [Blood Magic](mods/blood_magic.md) | blood_altar / master_ritual_stone |
| [Thaumic Energistics](mods/thaumic_energistics.md) | me_controller 复用 + essentia 总线 |
| [ThaumicTinkerer](mods/thaumic_tinkerer.md) | arcanebore / golemconnector 等,58 方法 |
| [AE2 Fluid Craft](mods/ae2_fluid_craft.md) | aelevelmaintainer / 流体接口 / 图案编辑器 |
| [Display Panels / Nuclear Control 2](mods/display_panels.md) | info_panel / 能量计数 / 热监控,25 方法 |
| [IndustrialCraft 2](mods/ic2.md) | reactor / crop / 能量驱动 |
| [Forestry](mods/forestry.md) | bee_housing 育种数据 |
| [Vanilla Minecraft](mods/vanilla.md) | inventory / fluid_handler / beacon 等 |
| [EnderIO](mods/enderio.md) | OC Conduit:16 色子通道导管 |
| [Random Things](mods/random_things.md) | onlinedetector / notificationinterface / creativeplayerinterface |
| [OpenModularTurrets](mods/open_modular_turrets.md) | 炮塔基座远程控制(16 方法) |
| [AsieLib](mods/asielib.md) | OC 扳手兼容层 |
| [MatterManipulator](mods/matter_manipulator.md) | OC 组件物品识别 |
| [Enhanced Lootbags](mods/enhanced_lootbags.md) | OC 物品掉落表 |

**Total: 544 `@Callback` methods across 19+ mods with confirmed `li.cil.oc.api` imports.**

## How Integration Works

OC connects to external blocks via an **Adapter** placed adjacent to the target block (or wirelessly via an **MFU** upgrade within 16 blocks). The adapter exposes the block as a named component (e.g. `gt_machine`, `me_controller`, `draconic_reactor`) accessible from Lua via `require('component')`.

```lua
local component = require('component')
local machine = component.gt_machine  -- GregTech machine
local me = component.me_controller    -- AE2 ME Controller
```

To discover available components and methods:

```lua
-- List all connected components
for k,v in component.list() do print(k,v) end

-- List methods for a specific component
for k,v in pairs(machine) do print(k,v) end
```


## Standard Hardware Stack

Most GTNH OC automation builds use a similar hardware configuration:

- **Tier 3 Computer Case** (or Microcontroller Case T2 for simple fluid scripts)
- **APU Tier 3** (functions as both CPU and Graphics Card)
- **Memory Tier 3.5**
- **Hard Disk Drive Tier 3**
- **EEPROM (Lua BIOS)** + **OpenOS Floppy Disk**
- **Adapter** (with MFU for wireless linking up to 16 blocks)
- **Keyboard** + **Screen Tier 3**
- Power via AE2 cable or Neutronium Energy Cell

Scripts are installed via `wget <url>/setup.lua && setup` and stopped with `CTRL+ALT+C`.

## Other Built-in OC Drivers

The following additional integrations are built into OpenComputers but may have limited relevance to GTNH gameplay:

| Mod | Drivers | Notes |
| --- | --- | --- |
| BuildCraft | `DriverControllable`, `DriverPipeTile` | Buildcraft pipes and controllable blocks |
| CoFH / Thermal Expansion | `DriverEnergyHandler/Provider/Receiver`, `DriverEnergyInfo`, `DriverRedstoneControl`, `DriverSecureTile`, `DriverEnderEnergy/Fluid/Item` | 8 drivers for CoFH energy & transport |
| ComputerCraft | `DriverComputerCraftMedia`, `DriverPeripheral` | CC peripheral compatibility & media |
| Deep Storage Unit | `DriverDeepStorageUnit` | DSU inventory access |
| Ender Storage | `DriverFrequencyOwner` | Ender chests/tanks |
| Galacticraft | `DriverWorldSensorCard` | World sensor card for space dimensions |
| GregTech (BEC) | `DriverBECDiode`, `DriverBECIONode`, `DriverBECStorage` | Battery Container blocks |
| Railcraft | `DriverAnchor`, `DriverBoilerFirebox`, `DriverSteamTurbine` | World anchor, boiler, turbine |
| StargateTech 2 | `DriverAbstractBusCard` | Abstract Bus card |
| Thermal Expansion | `DriverLamp` | Lamps |
| Tinkers' Mechworks | `DriverDrawBridge` | Draw bridge |
| Avaritia Addons | `DriverExtremeAutocrafter` | Extreme autocrafter |
