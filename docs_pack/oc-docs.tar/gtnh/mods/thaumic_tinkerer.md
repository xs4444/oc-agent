# ThaumicTinkerer — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## ThaumicTinkerer (Full OC Driver List)

ThaumicTinkerer provides its own OC drivers for Thaumcraft-related blocks, with 58 `@Callback` methods across 6 drivers plus additional tile entity components.

### Arcane Bore (`arcanebore`)

| Method | Description |
| --- | --- |
| `hasPickaxe()` | Whether the bore has a pickaxe |
| `hasFocus()` | Whether the bore has a focus |
| `isPickaxeBroken()` | Whether the pickaxe is near broken |
| `isWorking()` | Whether the bore is currently working |
| `getRadius()` | Get the bore's mining radius |
| `getSpeed()` | Get the bore's speed |
| `hasNativeClusters()` | Whether the bore produces native clusters |
| `getFortune()` | Get fortune level on the pickaxe |
| `hasSilkTouch()` | Whether the pickaxe has silk touch |

### Arcane Ear (`ArcaneEar`)

| Method | Description |
| --- | --- |
| `getNote():number` | Returns the note the ear is set to |
| `setNote(note:number)` | Sets the note the ear listens for |

### Brain in a Jar (`brainjar`)

| Method | Description |
| --- | --- |
| `getXP():number` | Returns the amount of XP in this jar |

### Deconstructor (`deconstructiontable`)

| Method | Description |
| --- | --- |
| `hasAspect():boolean` | Whether the table has an aspect waiting |
| `hasItem():boolean` | Whether the table has an item in the slot |
| `getAspect():string` | Returns the aspect in the deconstructor |

### Essentia Transport (`essentiaTransport`)

| Method | Description |
| --- | --- |
| `isConnectable(direction:number):boolean` | Whether pipe is connectable from this direction |
| `canInputFrom(direction:number):boolean` | Whether pipe can input from direction |
| `canOutputTo(direction:number):boolean` | Whether pipe can output to direction |
| `getSuctionType(direction:number):string` | Which aspect suction is set to |
| `getSuctionAmount(direction:number):number` | Amount of suction |
| `getEssentiaType(direction:number):string` | Which essentia is in pipe |
| `getEssentiaAmount(direction:number):number` | Amount of essentia in pipe |
| `getMinimumSuction():number` | Returns minimum suction |

### IAspectContainer (`IAspectContainer`)

| Method | Description |
| --- | --- |
| `getAspects():table` | Returns a list of tables containing aspect and quantity |
| `getAspectCount(aspectName:string):number` | Returns the amount of aspect in the block |

### Additional ThaumicTinkerer Tile Entities (SimpleComponent)

| Component | Block | Key Methods |
| --- | --- | --- |
| `tt_animationTablet` | Animation Tablet | `getRedstone()`, `setRedstone(boolean)`, `getLeftClick()`, `setLeftClick(boolean)`, `getRotation()`, `setRotation(number)`, `hasItem()`, `trigger()` |
| `tt_aspectanalyzer` | Aspect Analyzer | `hasItem():boolean`, `itemHasAspects():boolean`, `getAspects():table`, `getAspectCount():table`, `greet(name:string):string` |
| `tt_golemconnector` | Golem Connector | `getDecorations():table`, `getPosition():x,y,z`, `getType():string`, `getHealth():number`, `getCore():string`, `getHome():x,y,z,facing`, `setHome(x,y,z,facing)`, `getMarkers():table`, `setMarkers(list:table)`, `newMarker():table`, `addMarker(marker:table)`, `saveMarker(markerNum,marker)`, `deleteMarker(markerNum)`, `getMarker(markerNum)`, `getMarkerCount():number` |
| `tt_magnet` | Magnet | `isPulling():boolean`, `setPulling(boolean)`, `getSignal():number` |
| `tt_magnet` (inherited) | Mob Magnet | `getAdultSearch():boolean`, `setAdultSearch(boolean)` — plus all Magnet methods (`isPulling`, `setPulling`, `getSignal`) |

> Source: [ThaumicTinkerer source - OpenComputers drivers](https://github.com/GTNewHorizons/ThaumicTinkerer/tree/master/src/main/java/thaumic/tinkerer/common/peripheral/OpenComputers) and [tile entities](https://github.com/GTNewHorizons/ThaumicTinkerer/tree/master/src/main/java/thaumic/tinkerer/common/block/tile)

---
