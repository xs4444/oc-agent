# Thaumic Energistics — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Thaumic Energistics (Built-in Drivers)

OC ships with built-in drivers for Thaumic Energistics blocks, exposing them as AE2-style components.

| Component Name | Block | Source File |
| --- | --- | --- |
| `me_controller` | Thaumic Energistics Controller | `DriverController.scala` |
| (block interface) | Essentia IO Terminal block | `DriverBlockInterface.scala` |
| (essentia export bus) | Essentia Export Bus | `DriverEssentiaExportBus.scala` |
| (essentia import bus) | Essentia Import Bus | `DriverEssentiaImportBus.scala` |
| (essentia storage bus) | Essentia Storage Bus | `DriverEssentiaStorageBus.scala` |

The Thaumic Energistics Controller reuses the same `me_controller` component name as AE2's controller, extending it with the `NetworkControl` trait for essentia network management.

> Source: [OpenComputers source - thaumicenergistics integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/thaumicenergistics)

---
