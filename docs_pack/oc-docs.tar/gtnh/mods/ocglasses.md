# OCGlasses (AR Glasses) — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## OCGlasses (AR Glasses)

The OCGlasses add-on provides a HUD component (`glasses`) for displaying widgets on the player's screen. See [AR Glasses](../ar_glasses.md) for the full API.

Common applications: LSC power display ([Power Display](../power_display.md), [NIDAS](../nidas.md)), maintenance issue alerts, and real-time machine monitoring.

---
