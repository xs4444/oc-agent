# Random Things — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Random Things (OC Components)

Random Things provides three OC components, all using `SimpleComponent` (no Adapter needed — they join the OC network automatically).

### Online Detector (`onlinedetector`)

Detects whether specific players are online.

| Method | Description |
| --- | --- |
| `isPlayerOnline(name)` | Check if a player is currently online |
| `getPlayerList()` | Get a list of all online player names |

### Notification Interface (`notificationInterface`)

Sends in-game notifications to players from OC.

| Method | Description |
| --- | --- |
| `sendNotification(...)` | Send a notification to a player |

### Creative Player Interface (`playerinterface`)

Simulates a player identity for mods that require player interaction.

| Method | Description |
| --- | --- |
| `getPlayerName()` | Get the currently set player name |
| `setPlayerName(name)` | Set the simulated player name |
| `isCurrentlyConnected()` | Check if a player is connected to the interface |

> Source: [Random-Things source - TileEntities](https://github.com/GTNewHorizons/Random-Things/tree/master/src/main/java/lumien/randomthings/TileEntities)

---
