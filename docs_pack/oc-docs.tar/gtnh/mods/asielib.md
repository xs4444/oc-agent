# AsieLib — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## AsieLib (OC Wrench Provider)

AsieLib registers an OC wrench provider that allows OC's wrench API (`li.cil.oc.api.internal.Wrench`) items to be recognized and used by AsieLib's tool system. This is a compatibility layer, not a component — it enables OC wrenches to interact with AsieLib-compatible blocks.

> Source: [AsieLib source - OC tool provider](https://github.com/GTNewHorizons/AsieLib/tree/master/src/main/java/pl/asie/lib/integration/tool/oc)

---
