# OpenModularTurrets — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## OpenModularTurrets (OC Component)

OpenModularTurrets exposes its Turret Base blocks as OC components (via `SimpleComponent`), enabling full remote control of turret behavior from Lua scripts. Each turret tier has its own component name: `tierOneTurretBase` through `tierFiveTurretBase`.

Note: All methods require a Serial Port addon installed in the turret base; otherwise they return `"Computer access deactivated!"`.

### API Methods

| Method | Description |
| --- | --- |
| `getOwner():string` | Get the owner name of the turret base |
| `isAttacksMobs():boolean` | Check if attacking hostile mobs |
| `setAttacksMobs(boolean)` | Toggle attacking hostile mobs |
| `isAttacksNeutrals():boolean` | Check if attacking neutral mobs |
| `setAttacksNeutrals(boolean)` | Toggle attacking neutral mobs |
| `isAttacksPlayers():boolean` | Check if attacking players |
| `setAttacksPlayers(boolean)` | Toggle attacking players |
| `getTrustedPlayers():table` | Get table of trusted players |
| `addTrustedPlayer(name)` | Add a player to the trust list |
| `removeTrustedPlayer(name)` | Remove a player from the trust list |
| `getMaxEnergyStorage():number` | Get maximum energy storage |
| `getCurrentEnergyStorage():number` | Get current energy stored |
| `getActive():boolean` | Check if turret is currently active |
| `setInverted(boolean)` | Toggle redstone inversion state |
| `getInverted():boolean` | Check redstone inversion state |
| `getRedstone():boolean` | Check current redstone state |

### Components

| Component | Block |
| --- | --- |
| `tierOneTurretBase` | Turret Base Tier I |
| `tierTwoTurretBase` | Turret Base Tier II |
| `tierThreeTurretBase` | Turret Base Tier III |
| `tierFourTurretBase` | Turret Base Tier IV |
| `tierFiveTurretBase` | Turret Base Tier V |

> Source: [OpenModularTurrets source - TurretBase](https://github.com/GTNewHorizons/OpenModularTurrets/tree/master/src/main/java/openmodularturrets/tileentity/turretbase)

---
