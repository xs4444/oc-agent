# Blood Magic — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Blood Magic (Built-in Driver)

OpenComputers ships with built-in drivers for Blood Magic, exposing the Blood Altar and Master Ritual Stone as OC components.

### Blood Altar (`blood_altar`)

Place an Adapter next to a Blood Altar to expose these methods:

| Method | Description |
| --- | --- |
| `getCapacity()` | Get the altar's capacity |
| `getCurrentBlood()` | Get current blood amount |
| `getTier()` | Get the current altar tier |
| `getProgress()` | Get crafting progress |
| `getSacrificeMultiplier()` | Get sacrifice multiplier |
| `getSelfSacrificeMultiplier()` | Get self-sacrifice multiplier |
| `getOrbMultiplier()` | Get orb multiplier |
| `getDislocationMultiplier()` | Get dislocation multiplier |
| `getBufferCapacity()` | Get IO buffer capacity |

### Master Ritual Stone (`master_ritual_stone`)

| Method | Description |
| --- | --- |
| `getOwner()` | Get the owner's name |
| `getCurrentRitual()` | Get the current ritual name |
| `getCooldown()` | Get remaining cooldown |
| `getRunningTime()` | Get running time |
| `areTanksEmpty()` | Check if tanks are empty |

> Source: [OpenComputers source - bloodmagic integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/bloodmagic)

---
