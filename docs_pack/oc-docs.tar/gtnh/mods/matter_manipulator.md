# MatterManipulator — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## MatterManipulator (OC Item Provider)

MatterManipulator imports the OC API to recognize and handle OC component items (CPUs, RAM, cards, EEPROMs, HDDs, floppies) when building/copying structures. It properly handles tier matching, address stripping (removing OC node addresses when copying components), and loot disk label preservation.

This is an internal integration — no Lua component is exposed, but it ensures MatterManipulator can correctly replicate OC computer setups.

> Source: [MatterManipulator source - ComputerComponentItemProvider](https://github.com/GTNewHorizons/MatterManipulator/tree/master/src/main/java/com/recursive_pineapple/matter_manipulator/common/building/providers)

---
