# Applied Energistics 2 — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Applied Energistics 2

AE2 provides the deepest OC integration in GTNH. The AE2 source registers an OC integration module that:

1. **Registers a P2P tunnel type** for OpenComputers — OC cables, adapters, switches, access points, and network cards can be tunneled through AE2 P2P tunnels (`TunnelType.COMPUTER_MESSAGE`).
2. **Exposes ME Controller and ME Interface as OC components** — `me_controller` and `me_interface`.

### P2P Tunnel Attunement

The following OC items attune AE2 P2P tunnels to the `COMPUTER_MESSAGE` type:

- OC Cable, Adapter, Switch, Access Point
- LAN Card, Linked Card, Wireless Network Card
- Analyzer

### ME Controller API

| Method | Signature | Description |
| --- | --- | --- |
| `getItemsInNetwork` | `function([filter:table]):table` | Get stored items in the network |
| `getFluidsInNetwork` | `function():table` | Get stored fluids in the network |
| `getCpus` | `function():table` | Get available CPUs (view crafting status, cancel requests) |
| `getCraftables` | `function([filter:table]):table` | Get known item recipes for crafting requests |

The `getCraftables` result provides `getStack()` and `request([amount[, prioritizePower, cpuName]])`. The `request` result provides `hasFailed()`, `isCanceled()`, `isComputing()`, `isDone()` for tracking.

### ME Interface API

The ME Interface has all ME Controller functions plus:

| Method | Signature | Description |
| --- | --- | --- |
| `getInterfaceConfiguration` | `function([slot:number]):table` | Get stored item config in 9 slots |
| `setInterfaceConfiguration` | `function([slot][, database:address, entry:number[, size]]):boolean` | Configure slots using a database |
| `getInterfacePattern` | `function([slot:number]):table` | Get the given pattern in the interface |
| `setInterfacePatternInput` | `function(slot:number, index:number[, database:address, entry:number, size:number]):boolean` | Set pattern input from database |
| `setInterfacePatternOutput` | `function(slot:number, index:number[, database:address, entry:number, size:number]):boolean` | Set pattern output from database |
| `storeInterfacePatternInput` | `function(slot:number, index:number, database:address, entry:number):boolean` | Store pattern input to database |
| `storeInterfacePatternOutput` | `function(slot:number, index:number, database:address, entry:number):boolean` | Store pattern output to database |
| `clearInterfacePatternInput` | `function(slot:number, index:number):boolean` | Clear pattern input at the given index |
| `clearInterfacePatternOutput` | `function(slot:number, index:number):boolean` | Clear pattern output at the given index |

**Note:** `getFluidInterfaceConfiguration` / `setFluidInterfaceConfiguration` do **NOT** belong to `me_interface` — they are methods of the AE2 Fluid Craft Rework **`fluid_interface`** component (DriverBlockFluidInterface / DriverPartFluidInterface). See [AE2 Fluid Craft](ae2_fluid_craft.md).

### Item Stack Representation

When querying items, OC returns tables with: `damage`, `hasTag`, `isCraftable`, `label`, `maxDamage`, `maxSize`, `name`, `size`. When a Fluid Discretizer is present, fluids are represented as items with an additional `fluidDrop` field (`{amount, label, name}`). Filtering supports tables like `{label="drop of Hydrochloric Acid"}` or `{size=2}`.

> Source: [GTNH Wiki - OpenComputers](https://gtnh.miraheze.org/wiki/Open_Computers), [GTNH Wiki - Applied Energistics 2](https://gtnh.miraheze.org/wiki/Applied_Energistics_2)

---

## Applied Energistics 2 (Built-in Drivers, Full List)

In addition to the AE2 integration module (P2P tunnels) and the `me_controller`/`me_interface` APIs documented above, OC ships with built-in drivers for all major AE2 blocks:

| Component | Driver | Block |
| --- | --- | --- |
| `me_controller` | `DriverController` | ME Controller |
| `me_interface` | `DriverBlockInterface` / `DriverPartInterface` | ME Interface (block/part) |
| (export bus) | `DriverExportBus` | ME Export Bus |
| (import bus) | `DriverImportBus` | ME Import Bus |
| (storage bus) | `DriverStorageBus` | ME Storage Bus |
| (AE upgrade) | `DriverUpgradeAE` | AE2 Upgrade item |

### AE2 Fluid Craft (Built-in Drivers)

OC also ships with built-in drivers for AE2 Fluid Craft Rework blocks:

| Component | Driver | Block |
| --- | --- | --- |
| (fluid export bus) | `DriverFluidExportBus` | Fluid Export Bus |
| (fluid import bus) | `DriverFluidImportBus` | Fluid Import Bus |
| (fluid storage bus) | `DriverFluidStorageBus` | Fluid Storage Bus |
| (fluid interface part) | `DriverPartFluidInterface` | Fluid Interface (part) |

> Source: [OpenComputers source - appeng integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/appeng) and [ae2fc integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/ae2fc)

---
