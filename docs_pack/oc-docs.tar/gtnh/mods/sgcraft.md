# Stargate / SGCraft — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Stargate / SGCraft (`stargate`)

SGCraft provides an **OC Stargate Interface** block that exposes the `stargate` component with 11 `@Callback` methods. The interface block implements `Environment` directly (not via Adapter) and joins the OC network automatically. Prior to GTNH 2.7, this was the **only** way to dial another Stargate programmatically.

The interface also supports **network packet forwarding** — with a network card installed in its upgrade slot, OC network packets can be forwarded through an active stargate connection to the remote side.

### API Methods

| Method | Description |
| --- | --- |
| `stargateState()` | Returns state, chevrons engaged, and dialing direction |
| `energyAvailable()` | Get available energy in the stargate's energy buffer |
| `energyToDial(address:string)` | Get energy required to dial the specified address |
| `localAddress()` | Get the local stargate address |
| `remoteAddress()` | Get the remote stargate address (if connected) |
| `dial(address:string)` | Dial another stargate (lowercase, no hyphens) |
| `disconnect()` | Disconnect the active stargate connection |
| `irisState()` | Get the current iris state |
| `openIris()` | Open the iris |
| `closeIris()` | Close the iris |
| `sendMessage(...)` | Send data through the stargate to the remote side |

### Hardware Required

OC Stargate Interface, T3 Computer Case, T3 Screen(s), T3 Memory, T3 HDD, **Creative APU**, Internet Card, EEPROM, OpenOS Floppy, Power Converter, Keyboard.

### Setup

```bash
wget https://raw.githubusercontent.com/OneDayStudios/DiallingComputer/master/StargateControl.lua
```

The power unit only accepts RF power (use a capacitor bank). Connections are one-way — the remote stargate must be dialed separately for return travel.

> Source: [SGCraft source - OC interface](https://github.com/GTNewHorizons/SGCraft/tree/master/src/main/java/gcewing/sg/compat/oc)

---
