# Enhanced Lootbags — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Enhanced Lootbags — OC Item Drops

OpenComputers items appear in three Enhanced Lootbag types, providing a source of OC components beyond crafting.

### Tier 1 Computer Lootbag (1-2 drops)

Screen (T1) (4), Keyboard, Card Container (T1), Power Converter, Network Card, OpenComputers Manual, Card Base, Disk Drive, Redstone I/O (2), Microchip (T1) (4), Cable (16), Scrench, CPU (T1), Analyzer, Disk Platter (4), Transposer (2), EEPROM, Data Card (T1), Database Upgrade (T1), Memory (T1) (2), Adapter, Waypoint, Hover Upgrade (T1), Computer Case (T1), HDD (T1), Floppy Disk (8), ALU (8), Control Unit (CU), Drone Case (T1), Battery Upgrade (T1), Upgrade Container (T1), EEPROM, Colorful Lamp, Chat Box, Camera, Speech Upgrade, Leash Upgrade, Experience Upgrade, Chest Upgrade, Crafting Upgrade, Tank Upgrade, Beep Card, Redstone Card (T1), Colorful Upgrade

### Tier 2 Computer Lootbag (1-2 drops)

Relay, Electronics Assembler, BitCoin (2)

### Computer Floppies Lootbag (1 drop)

Plan9k (OS), Floppy Disk, Network (Network Stack), Digger, OPPM (Package Manager), OpenLoader (Boot Loader), OpenIRC (IRC Client), OpenOS (OS), Mazer, Builder, Generator Upgrade Software, Data Card Software

> Source: [GTNH Wiki - Enhanced Lootbags](https://gtnh.miraheze.org/wiki/Enhanced_Lootbags)
