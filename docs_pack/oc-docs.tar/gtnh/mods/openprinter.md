# OpenPrinter — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## OpenPrinter (Full API)

OpenPrinter provides a Printer block (`openprinter`) with 12 `@Callback` methods for in-game document printing. The printer has 20 inventory slots (slots 0-13 used): slot 0 = black ink, slot 1 = color ink, slot 2 = paper/paper roll, slots 3-12 = output, slot 13 = scan input.

### Printer (`openprinter`)

| Method | Description |
| --- | --- |
| `greet()` | Returns a Dante quote (easter egg) |
| `scanLine(line:number)` | Get a specific line of text from the scanned page in slot 13 |
| `scan()` | Scan the page in slot 13 — returns pageTitle and a table of all lines |
| `printTag(name:string)` | Print a Name Tag (requires name tags in slot 2, black ink in slot 0) |
| `print([copies:number])` | Print the buffered text to pages (default 9 copies). Consumes paper and ink |
| `writeln(text:string[, color:number[, alignment:string]])` | Write a line to the print buffer (max 20 lines). Color is RGB int, alignment is "left"/"center"/"right" |
| `setTitle(title:string)` | Set the page title for the next print |
| `getPaperLevel()` | Get remaining paper (256 for roll, stackSize for individual sheets) |
| `getBlackInkLevel()` | Get remaining black ink uses |
| `getColorInkLevel()` | Get remaining color ink uses |
| `charCount(text:string)` | Count visible characters (strips Minecraft formatting codes) |
| `clear()` | Clear the print buffer, colors, alignments, and title |

> Source: [OpenPrinter source - PrinterTE](https://github.com/GTNewHorizons/OpenPrinter/tree/master/src/main/java/pcl/openprinter/tileentity)

---
