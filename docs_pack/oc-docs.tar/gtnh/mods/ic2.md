# IndustrialCraft 2 — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## IndustrialCraft 2 (Built-in Drivers)

OC ships with built-in drivers for IC2 blocks.

### Nuclear Reactor (`reactor`)

Exposes the IC2 Nuclear Reactor as an OC component for monitoring and control.

| Method | Description |
| --- | --- |
| `setActive(boolean)` | Activate or deactivate the reactor |
| `getHeat()` | Get current reactor heat |
| `getMaxHeat()` | Get maximum heat before explosion |
| `getReactorEnergyOutput()` | Get energy output (not multiplied by base EU/t) |
| `getReactorEUOutput()` | Get base EU/t value |
| `producesEnergy()` | Whether the reactor is active and producing energy |
| `getSlotInfo(x, y)` | Get info about item in reactor slot (item, canStoreHeat, heat, maxHeat) |

### IC2 Crops (`crop`)

Any block implementing `ICropTile` is exposed as a `crop` component — the foundation of the [Crop Breeding](../crop_breeding.md) automation.

| Method | Description |
| --- | --- |
| `getSize()` | Get current growth size |
| `getGrowth()` | Get growth stat |
| `getGain()` | Get gain stat |
| `getResistance()` | Get resistance stat |
| `getNutrientStorage()` | Get nutrient storage |
| `getHydrationStorage()` | Get hydration storage |
| `getWeedExStorage()` | Get weed-ex storage |
| `getHumidity()` | Get humidity environmental stat |
| `getNutrients()` | Get nutrients environmental stat |
| `getAirQuality()` | Get air quality environmental stat |
| `getName()` | Get crop name |
| `getRootsLength()` | Get roots length |
| `getTier()` | Get crop tier |
| `maxSize()` | Get maximum growth size |
| `canGrow()` | Whether the crop can grow further |
| `getOptimalHavestSize()` | Get optimal harvest size |

Additional IC2 drivers: `DriverEnergyConductor`, `DriverEnergySink`, `DriverEnergySource`, `DriverEnergyStorage`, `DriverMassFab` (mass fabricator), `DriverReactorChamber`, `DriverTeleporter`.

> Source: [OpenComputers source - ic2 integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/ic2)

---
