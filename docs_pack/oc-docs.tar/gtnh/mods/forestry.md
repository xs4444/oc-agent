# Forestry — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Forestry (Built-in Drivers)

OC ships with built-in drivers for Forestry bee housing blocks.

### Bee Housing (`bee_housing`)

Any block implementing `IBeeHousing` (Apiary, Bee House, Alveary, etc.) is exposed as a `bee_housing` component.

| Method | Description |
| --- | --- |
| `canBreed()` | Whether bees can breed in this housing |
| `getDrone()` | Get the current drone as a table |
| `getQueen()` | Get the current queen as a table |
| `getBeeBreedingData()` | Get the full breeding mutation list (allele1, allele2, chance, specialConditions, result) |
| `listAllSpecies()` | Get all known bee species from mutations |
| `getBeeParents(beeName)` | Get parent mutations for a specific bee species |

Additional Forestry drivers: `DriverAnalyzer` (apiary analyzer), `DriverUpgradeBeekeeper` (beekeeper upgrade item).

> Source: [OpenComputers source - forestry integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/forestry)

---
