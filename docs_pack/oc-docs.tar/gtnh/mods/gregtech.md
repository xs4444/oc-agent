# GregTech — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## GregTech

OC integrates with GregTech machines via the `gt_machine` component, exposed through an Adapter.

### Common API Methods

| Method | Description |
| --- | --- |
| `getName()` | Returns the machine's internal name (e.g. `projectmodulepumpt1`) |
| `isMachineActive()` | Returns whether the machine is currently running |
| `setWorkAllowed(boolean)` | Enables/disables the machine |

**Note:** `setParameter()` and `getProblem()` do **NOT** exist on `gt_machine`. `setParameter(key, value)` is a Computronics `tt_machine` method for Techtect parametrized machines only.

The full `gt_machine` method list also includes `hasWork()`, `getWorkProgress()`, `getWorkMaxProgress()`, `isWorkAllowed()`, and `getCoordinates()` — see [Computronics](computronics.md) for the complete list.

> **Attribution:** `gt_machine` is registered by the **Computronics** mod (not OC built-in): `DriverMachine` (priority 1, 8 methods), `DriverBaseMetaTileEntity` (EU/steam storage), `DriverDeviceInformation` (`getSensorInformation`), `DriverGregTechCircuitConfigurableMachine` (circuit config).

### Bacterial Vat — Fluid Level Control

A microcontroller with a **Transposer** component maintains the exact fluid level in a Bacterial Vat output hatch for maximum x1,001 output. The script calculates the minimum fluid amount that guarantees maximum output and pumps excess away.

```lua
local t = component.proxy(component.list('transposer')())
local max = t.getTankCapacity(1)
local min = math.ceil((1-math.sqrt(0.001))*max/2)

while true do
  local level = t.getTankLevel(1)
  if level > min then
    t.transferFluid(1, 0, level - min)
  end
  computer.pullSignal(5)  -- Sleep 5 seconds
end
```

**Hardware:** Microcontroller Case T2, Transposer (+ Fluid Regulator), RITEG upgrade (eliminates power cables), CPU T1, Memory T1, flashed EEPROM.

> Source: [GTNH Wiki - Bacterial Vat](https://gtnh.miraheze.org/wiki/Bacterial_Vat)

### Black Hole Containment Field — Full Automation

A ~120-line script (`bhc.lua`) fully automates BHC timing: calculates exact spacetime needed, provides void protection, prevents black-hole creation when resources are short, and handles wireless redstone signalling.

**Components used:** `gt_machine` (BHC controller via MFU→Adapter), `redstone` (Redstone I/O with wireless receiver/transmitter), `transposer`.

```lua
local component = require('component')
local sides = require('sides')
local bhc = component.gt_machine
local r = component.redstone
local t = component.transposer

-- Config
local maxRuntime = 100        -- Max runtime (s) before closing
local targetStability = 18    -- Target stability (%) for halting decay
local useCollapser = true     -- Use Black Hole Collapsers
local voidProtection = true   -- Consume extra spacetime to save last recipe
local endEarly = true         -- End injection early if machine is idle
```

**Sides configuration:** `[north, south, east, west, up, down]` for receiverSide, transmitterSide, hatchSide, interfaceSide, stockerSide, busSide. Wireless redstone on channel 1 triggers spacetime hatch via machine controller cover.

> Source: [GTNH Wiki - Pseudostable Black Hole Containment Field](https://gtnh.miraheze.org/wiki/Pseudostable_Black_Hole_Containment_Field)

### SLAM — Antimatter/Matter Injection

Moves exact amounts of antimatter + matter (43,646L per burn, configurable) into the SLAM's quadruple input hatch on a 5-second loop. A microcontroller cannot be used here — it does not move fluids fast enough; a regular Transposer is required.

```lua
local sides = require('sides')
local component = require('component')
local t = component.proxy(component.list('transposer')())
local target = 43646

while true do
  local level1 = t.getTankLevel(sides.west)  -- Antimatter
  local level2 = t.getTankLevel(sides.east)  -- Matter
  if (level1 >= target) and (level2 >= target) then
    t.transferFluid(sides.west, sides.down, target)
    t.transferFluid(sides.east, sides.down, target)
  end
  os.sleep(5)
end
```

> Source: [GTNH Wiki - Shielded Lagrangian Annihilation Matrix](https://gtnh.miraheze.org/wiki/Shielded_Lagrangian_Annihilation_Matrix)

### Space Elevator — Pumping Module Automation

OC automatically switches Space Elevator Pumping Module settings (gas/planet/batch size) based on which fluids are low — similar to a level maintainer. See [Space Pumping](../space_pumping.md) for full scripts and fluid tables.

---

## GregTech Energy (Built-in Drivers)

OC ships with dedicated drivers for GregTech energy blocks, separate from the `gt_machine` component.

### Lapotronic Supercapacitor (`LSC`)

The LSC driver exposes the GregTech Lapotronic Supercapacitor as an OC component named `LSC`. This is the component used by [NIDAS](../nidas.md) and [Power Display](../power_display.md) for real-time HUD monitoring.

| Method | Description |
| --- | --- |
| `getStoredEU()` | Returns stored EU (clamped to Long.MaxValue to prevent overflow) |
| `getStoredEUString()` | Returns stored EU as a string (for HUGE amounts exceeding Long) |
| `getEUCapacity()` | Returns EU capacity (clamped to Long.MaxValue) |
| `getEUCapacityString()` | Returns EU capacity as a string (for HUGE amounts) |

```lua
local component = require('component')
local lsc = component.LSC
print("Stored: " .. lsc.getStoredEUString() .. " / " .. lsc.getEUCapacityString())
```

### Generic Energy Container (`gt_energyContainer`)

Any GregTech block implementing `IBasicEnergyContainer` is automatically exposed as a `gt_energyContainer` component (priority -1, lower than machine-specific drivers).

| Method | Description |
| --- | --- |
| `getStoredEU()` | Returns stored EU |
| `getStoredEUString()` | Returns stored EU as string (unsigned, for huge amounts) |
| `getEUCapacity()` | Returns EU capacity |
| `getEUCapacityString()` | Returns EU capacity as string (unsigned) |
| `getSteamCapacity()` | Returns steam capacity (in EU units) |
| `getStoredSteam()` | Returns stored steam (in EU units) |
| `getOutputVoltage()` | Gets output in EU/p |
| `getOutputAmperage()` | Gets energy packets per tick |
| `getInputVoltage()` | Gets maximum input in EU/p |
| `getAverageElectricInput()` | Average electricity input over last 5 ticks |
| `getAverageElectricOutput()` | Average electricity output over last 5 ticks |

> Source: [OpenComputers source - gregtech integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/gregtech)

---

## GregTech Data Server (`GT-Data Server`)

GregTech itself (GT5-Unofficial) imports the OC API to provide a **Data Server** block — a tile entity that stores and serves Data Orb / Data Stick data to OC computers.

### API Methods

| Method | Description |
| --- | --- |
| `listData()` | List all stored data entries (ID + title) |
| `imprintOrb()` | Imprint a data orb (currently returns false — placeholder) |

The Data Server accepts Data Orbs and Data Sticks in its inventory, reads their NBT data, and stores it in an internal database indexed by unique IDs. Data sticks are categorized as eBooks, Punch Cards, Map Data, or Custom Data based on their NBT tags.

**Implementation:** Uses `SimpleComponent` interface (not `ManagedEnvironment`), meaning the component is automatically registered with OC without an Adapter — it appears as `GT-Data Server` on the OC network.

> Source: [GT5-Unofficial source - openComputers crossmod](https://github.com/GTNewHorizons/GT5-Unofficial/tree/master/src/main/java/bwcrossmod/openComputers)

---
