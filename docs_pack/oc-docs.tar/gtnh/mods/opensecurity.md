# OpenSecurity — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## OpenSecurity (Full Component List)

OpenSecurity provides 11 OC components. Only the Alarm is exposed via `SimpleComponent` (auto-registered); every other block implements OC `Environment` with a manually created component node (`.withComponent(...)`). With 61 `@Callback` methods total (including the RFID Reader card driver), it is the second-largest OC addon after Computronics.

### Alarm (`os_alarm`)

| Method | Description |
| --- | --- |
| `setRange(range:integer):string` | Sets the range in blocks of the alarm |
| `setAlarm(soundName:string):string` | Sets the alarm sound |
| `activate():string` | Activates the alarm |
| `listSounds():table` | Returns a table of available alarm sounds |
| `playSoundAt(x:integer, y:integer, z:integer, sound:string, range:number):string` | Plays a sound at the given coordinates |
| `deactivate():string` | Deactivates the alarm |

### Biometric Reader (`os_biometric`)

| Method | Description |
| --- | --- |
| `setEventName(name:String):boolean` | Sets the name of the event that gets sent |

### Card Writer (`os_cardwriter`)

Card writer for RFID/security cards.

| Method | Description |
| --- | --- |
| `flash(code:string, title:string, locked:boolean):boolean,string` | Flashes an EEPROM with the given code (requires an EEPROM in the input slot) |
| `write(data:string, displayName:string, locked:boolean, color:number):boolean,string` | Writes data to the card (64 chars for RFID, 128 for magstripe); returns `true` plus the card UUID |

### Data Block (`os_datablock`)

| Method | Description |
| --- | --- |
| `getLimit():number` | The maximum size of data that can be passed to other functions of the block |
| `encode64(data:string):string` | Applies base64 encoding to the data |
| `decode64(data:string):string` | Applies base64 decoding to the data |
| `deflate(data:string):string` | Applies deflate compression to the data |
| `inflate(data:string):string` | Applies inflate decompression to the data |
| `sha256(data:string):string` | Computes a SHA2-256 hash of the data (binary result) |
| `md5(data:string):string` | Computes an MD5 hash of the data (binary result) |
| `crc32(data:string):string` | Computes a CRC-32 hash of the data (binary result) |
| `rot13(data:string):string` | Applies rot13 to the data |
| `bCryptHash(plaintext:string, rounds?:number):string` | Computes the bcrypt hash of the input (optional rounds, clamped to 4-15) |
| `bCryptCheck(plaintext:string, hash:string):boolean` | Checks a bcrypt input against a hash |

### Door Controller (`os_door`)

Door controller for secure door management.

| Method | Description |
| --- | --- |
| `removePassword(password:string):boolean,string` | Removes the door password |
| `setPassword(password:string[, newPassword:string]):boolean,string` | Sets (or changes) the door password |
| `isOpen():boolean` | Whether the door is currently open |
| `open():boolean` | Opens the door |
| `close():boolean` | Closes the door |
| `toggle(password?:string):boolean,string` | Toggles the door open/closed (password required if one is set) |

### Energy Turret (`os_energyturret`)

| Method | Description |
| --- | --- |
| `getYaw():number` | Current real yaw |
| `getPitch():number` | Current real pitch |
| `isOnTarget():boolean,number` | Whether the gun has reached the set position, plus the distance to it |
| `isReady():boolean` | Whether the gun is ready to fire again (cooled down and armed) |
| `isPowered():boolean` | Whether the gun is powered |
| `extendShaft(length:number):number` | Extends the gun shaft (0-2) |
| `getShaftLength():number` | Gets the gun shaft extension |
| `moveTo(yaw:number, pitch:number):boolean` | Changes the gun's setpoint (yaw 0-360, pitch -45 to 90) |
| `moveToRadians(yaw:number, pitch:number):boolean` | Changes the gun's setpoint in radians |
| `setArmed(armed:boolean):boolean` | Arms or disarms the gun |
| `powerOn():boolean` | Powers the gun on |
| `powerOff():boolean` | Powers the gun off |
| `fire():boolean` | Fires the gun (throws an error if not armed, not cooled down or not powered) |

### Entity Detector (`os_entdetector`)

Entity detection and tracking component.

| Method | Description |
| --- | --- |
| `getLoc():number,number,number` | Returns the detector's x, y, z position |
| `scanPlayers(range?:number, offset?:boolean):table` | Pushes an `entityDetect` signal for each player in range; optional range and offset |
| `scanEntities(range?:number, offset?:boolean):table` | Pushes an `entityDetect` signal for each entity in range (excluding players); optional range and offset |

### KVM

The KVM (Keyboard/Video/Monitor switch) creates its OC node **without** `withComponent`, so it is **not** exposed as an OC component and has no `@Callback` methods.

### Keypad Lock (`os_keypad`)

| Method | Description |
| --- | --- |
| `setEventName(name:String):boolean` | Sets the name of the event sent when a key is pressed |
| `setShouldBeep(beep:boolean):boolean` | Sets if keys should beep when pressed |
| `setDisplay(text:string, color?:number):boolean` | Sets the display string (0-8 chars) and color (0-7) |
| `setKey(idx:number, text:string, color:number):boolean` | Sets the key text (1-2 chars) |

### Magnetic Card Reader (`os_magreader`)

Magnetic stripe card reader component.

| Method | Description |
| --- | --- |
| `setEventName(name:string):boolean` | Sets the name of the event sent when a card is swiped |

### RFID Reader (`os_rfidreader`)

RFID card reader for access control. Available both as a tile entity and as the `RFIDReaderCardDriver` card item; both expose the component `os_rfidreader`.

| Method | Description |
| --- | --- |
| `scan(range?:number):table` | Pushes an `rfidData` signal for each found RFID card on players in range |

### Secure Network Card Driver (component `modem`)

| Method | Description |
| --- | --- |
| `generateUUID():boolean` | Randomises the UUID of the secure network card |

### Switchable Hub (`os_switchinghub`)

Network hub that can be toggled on/off via OC.

| Method | Description |
| --- | --- |
| `setPassword(password:string[, newPassword:string]):string` | Sets (or changes) the hub password |
| `setSide(side:number, enabled:boolean, password:string):string` | Enables/disables a side of the hub (password required if one is set) |

> Source: [OpenSecurity source - drivers](https://github.com/GTNewHorizons/OpenSecurity/tree/master/src/main/java/pcl/opensecurity/drivers) and [tileentities](https://github.com/GTNewHorizons/OpenSecurity/tree/master/src/main/java/pcl/opensecurity/tileentity)

---
