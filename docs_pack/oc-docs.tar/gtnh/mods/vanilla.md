# Vanilla Minecraft — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Vanilla Minecraft (Built-in Drivers)

OC ships with built-in drivers for vanilla Minecraft blocks.

### Inventory (`inventory`)

Any block implementing `IInventory` (chests, furnaces, brewing stands, etc.) is automatically exposed as an `inventory` component.

| Method | Description |
| --- | --- |
| `getInventoryName()` | Get the inventory's name |
| `getInventorySize()` | Get number of slots |
| `getSlotStackSize(slot)` | Get stack size in specified slot (1-indexed) |
| `getSlotMaxStackSize(slot)` | Get max stack size for slot |
| `compareStacks(slotA, slotB)` | Compare two item stacks for equality |
| `transferStack(slotA, slotB[, count])` | Move items from slotA to slotB (swap if incompatible) |
| `getStackInSlot(slot)` | Get item stack description (requires `allowItemStackInspection` in config) |
| `getAllStacks()` | Get all item stacks in the inventory |

**Note:** Some methods check permissions via a fake player and may return `"permission denied"` if the block is protected (e.g. by Server Utilities).

### Other Vanilla Drivers

| Component | Block | Actual Methods (verified) |
| --- | --- | --- |
| `beacon` | Beacon | `getLevels()`, `getPrimaryEffect()`, `getSecondaryEffect()` |
| `brewing_stand` | Brewing Stand | `getBrewTime()` (ONLY — `getIngredient`/`getFuel` do NOT exist) |
| `command_block` | Command Block | `getCommand()`, `setCommand()`, `executeCommand()` (NOT `execute`) |
| `comparator` | Comparator | `getOutputSignal()` (ONLY — `getOutputSide`/`getOutputStrength`/`setOutputStrength` do NOT exist) |
| `fluid_handler` | Fluid blocks | `getTankInfo()` (ONLY — `drain`/`fill` do NOT exist) |
| `furnace` | Furnace | `getBurnTime()`, `getCookTime()`, `getCurrentItemBurnTime()`, `isBurning()` (NOT `getCookTimeTotal`/`getInput`/`getOutput`) |
| `mob_spawner` | Mob Spawner | `getSpawningMobName()` (NOT `getSpawnerType`/`setSpawnerType`) |
| `note_block` | Note Block | `getPitch()`, `setPitch()`, `trigger()` (NOT `getNote`/`setNote`) |
| `jukebox` | Jukebox | Component name is `jukebox` (NOT `record_player`); methods `getRecord()`, `play()`, `stop()` |
| `inventory` | Chests etc | `getInventoryName()`, `getInventorySize()`, `getSlotStackSize()`, `getSlotMaxStackSize()`, `compareStacks()`, `transferStack()`, `getStackInSlot()`, `getAllStacks()` |

> Source: [OpenComputers source - vanilla integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/vanilla)

---
