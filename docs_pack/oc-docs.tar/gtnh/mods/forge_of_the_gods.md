# Forge of the Gods — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Forge of the Gods

OC + AE2 crafting is listed as "Method 1" for automating the Forge of the Gods, combining OC's ability to issue AE2 crafting requests with pattern management.

> Source: [GTNH Wiki - Forge of the Gods](https://gtnh.miraheze.org/wiki/Forge_of_the_Gods)

---
