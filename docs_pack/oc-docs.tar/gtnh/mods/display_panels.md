# Display Panels / Nuclear Control 2 — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Display Panels / Nuclear Control 2 (Full OC Driver List)

The Display Panels mod (Nuclear Control 2) provides 6 OC drivers with 24 `@Callback` methods for its information display and monitoring blocks.

### Info Panel (`info_panel`)

| Method | Description |
| --- | --- |
| `getBackgroundColor():number` | Get the panel's background color |
| `getTextColor():number` | Get the panel's text color |
| `hasColorUpgrade():boolean` | Check if color upgrade is installed |
| `hasWebUpgrade():boolean` | Check if web upgrade is installed |

### Advanced Info Panel (`advanced_info_panel`)

Extended info panel with rotation and color setting support.

| Method | Description |
| --- | --- |
| `getThickness():number` | Gets the thickness of the panel |
| `getRotationHorizonally():number` | Gets the horizontal rotation of the panel |
| `getRotationVertically():number` | Gets the vertical rotation of the panel |
| `getBackgroundColor():number` | Gets the background color of the panel |
| `getTextColor():number` | Gets the text color of the panel |
| `hasWebUpgrade():boolean` | Check if web upgrade is installed |
| `setThickness(value:number)` | Sets the thickness of the panel (1-16) |
| `rotateHorizonally(value:number)` | Sets the horizontal rotation of the panel (1-16) |
| `rotateVertically(value:number)` | Sets the vertical rotation of the panel (1-16) |

### Average Counter (`average_counter`)

| Method | Description |
| --- | --- |
| `getPeriod():number` | Gets the period (in seconds) of the average counter |
| `getAverage():number` | Gets the average of the counter |
| `getEnergyType():number` | Gets the energy type (0=EU, 1=RF, -1=unknown) |

### Energy Counter (`energy_counter`)

| Method | Description |
| --- | --- |
| `getCount():number` | Gets the count of the counter |
| `getEnergyType():number` | Gets the energy type (0=EU, 1=RF, -1=unknown) |

### Howler Alarm (`howler_alarm`)

| Method | Description |
| --- | --- |
| `getSoundName():string` | Gets the sound name |
| `getRange():number` | Gets the range set |

### Thermal Monitor (`thermal_monitor`)

| Method | Description |
| --- | --- |
| `isOverheated():boolean` | Whether the reactor is overheated |
| `getReactorStatus():number` | Returns 1 if overheated, 0 if not, -1 if reactor not found |
| `getHeatLevel():number` | Gets the set heat level of the reactor |
| `setHeatLevel(number)` | Sets the heat level of the reactor |

> Source: [Display-Panels source - opencomputers crossmod](https://github.com/GTNewHorizons/Display-Panels/tree/master/src/main/java/shedar/mods/ic2/nuclearcontrol/crossmod/opencomputers)

---
