# Computronics — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Computronics

Computronics is a ComputerCraft & OpenComputers add-on providing:

- **Radar** block/upgrade — Detects entities (players, mobs, items) within a configurable range via `getEntities()`, `getPlayers()`, `getMobs()`, `getItems()`.
- **Tape Drive** — Read/write magnetic tape storage for data persistence.
- **Radio** — Wireless communication over configurable frequencies and ranges.
- **Colorful Lamp** — Controllable via the OpenComputers API.

Source code confirms OC driver implementations in `pl.asie.computronics.oc.driver` (e.g. `RobotUpgradeRadar`) and CC peripheral implementations in `pl.asie.computronics.cc`.

---

## Computronics OC Drivers (Full List)

Computronics provides the most extensive set of OC drivers among GTNH addons. In addition to the Radar, Tape, and Radio mentioned above, Computronics includes:

### GregTech Machine Driver (`gt_machine`)

Provides progress monitoring for GregTech machines (note: this is the Computronics driver, separate from OC's built-in GT integration).

| Method | Description |
| --- | --- |
| `hasWork()` | Whether the machine has work to do |
| `getWorkProgress()` | Get current progress |
| `getWorkMaxProgress()` | Get max progress |
| `isWorkAllowed()` | Whether the machine is allowed to work |
| `setWorkAllowed(boolean)` | Enable/disable the machine |
| `isMachineActive()` | Whether the machine is currently active |
| `getCoordinates()` | Get machine coordinates (if enabled in config) |
| `getName()` | Get the machine's internal name |

`gt_machine` is registered by multiple drivers (higher-priority drivers override lower ones for the same tile):

| Driver | Additional Methods | Component |
| --- | --- | --- |
| `DriverBaseMetaTileEntity` | `getEUStored()`, `getSteamStored()`, `getEUMaxStored()`, `getSteamMaxStored()`, `getEUInputAverage()`, `getEUOutputAverage()`, `getOwnerName()` | `gt_machine` |
| `DriverDeviceInformation` | `getSensorInformation()` | `gt_machine` |
| `DriverGregTechCircuitConfigurableMachine` | `getCircuitConfiguration()`, `setCircuitConfiguration()` | `gt_machine` |
| `DriverBatteryBuffer` | `getBatteryCharge(slot)`, `getMaxBatteryCharge(slot)` | `gt_batterybuffer` |
| `DriverDigitalChest` | `getContents()` | `digital_chest` |
| `DriverParametrized` (tectech) | `setParameter(key, value)`, `getParameters()` | `tt_machine` |

### Other Computronics OC Drivers

| Integration | Driver | Component |
| --- | --- | --- |
| EnderIO | DriverTelepad, DriverCapacitorBank, DriverPowerStorage, DriverPowerMonitor, DriverAbstractMachine, DriverAbstractPoweredMachine, DriverIOConfigurable, DriverRedstoneControllable, DriverProgressTile, DriverHasExperience, DriverVacuumChest, DriverTransceiver, DriverWeatherObelisk | Various EIO blocks |
| Railcraft | DriverElectricGrid, DriverRoutingDetector, DriverRoutingSwitch, DriverLauncherTrack, DriverLimiterTrack, DriverLocomotiveTrack, DriverPoweredTrack, DriverPrimingTrack, DriverRoutingTrack | Rail blocks & routing |
| BuildCraft | DriverHeatable | Heatable blocks |
| BuildCraft (drones) | Drone Docking Station (block) + Docking Upgrade (drone upgrade item) | Drone docking station & docking upgrade (`ItemDroneStation`, `ItemDockingUpgrade` → `DriverDockingUpgrade`) |
| Storage Drawers | DriverDrawerGroup | Drawer systems |
| BetterStorage | DriverCrateStorageOld, DriverCrateStorageNew | Crates (`crate` component, `getContents()`, `getCapacity()`) |
| FSP (Steamcraft) | DriverSteamTransporter | Steam transporter (`FSP_SteamTransporter` component, `getSteamPressure()`, `getSteamCapacity()`, `getSteamAmount()`) |
| Redlogic | DriverLamp | Lamps |
| Mekanism | DriverStrictEnergyStorage | Energy storage |
| Factorization | DriverChargeConductor | Charge conductors |
| Armourer's Workshop | DriverMannequin | Mannequins |
| Flamingo | DriverFlamingo | Flamingo blocks |
| AE2 | DriverSpatialIOPort | Spatial IO port |
| Draconic Evolution | DriverExtendedRFStorage | RF storage |

Computronics also provides OC-specific items: `DriverCardBeep`, `DriverCardBoom`, `DriverCardFX`, `DriverCardNoise`, `DriverCardSound`, `DriverCardSpoof`, `DriverMagicalMemory`, `DriverBoardBoom`, `DriverBoardCapacitor`, `DriverBoardLight`, `DriverBoardSwitch`.

> Source: [Computronics source - integration](https://github.com/GTNewHorizons/Computronics/tree/master/src/main/java/pl/asie/computronics/integration)

---
