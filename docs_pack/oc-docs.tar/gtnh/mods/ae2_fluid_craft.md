# AE2 Fluid Craft — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## AE2 Fluid Craft (OC Drivers)

The AE2 Fluid Craft Rework mod provides OC drivers for its custom AE2 blocks:

### Level Maintainer (`level_maintainer`)

Exposes the AE2 Level Maintainer as an OC component, enabling programmatic configuration of request slots.

| Method | Description |
| --- | --- |
| `getSlot([slot:number]):table` | Get slot status (item damage, label, name, quantity, batch, isFluid, isEnable, isDone) |
| `setSlot(slot:number[, database:address, index:number], quantity:number, batch:number):boolean` | Configure a slot (optionally set item from database) |
| `isDone(slot:number):boolean` | Get crafting task state for slot |
| `isEnable(slot:number):boolean` | Get crafting state of slot |
| `setEnable(slot:number, value:boolean):boolean` | Set crafting state of slot |
| `active():boolean` | Get Level Maintainer active state |

Additional AE2FluidCraft OC components: `fluid_interface` (via `DriverDualFluidInterface`, dual fluid interface) and `oc_pattern_editor` (via `DriverOCPatternEditor`, pattern editor).

> Source: [AE2FluidCraft-Rework source - opencomputers crossmod](https://github.com/GTNewHorizons/AE2FluidCraft-Rework/tree/master/src/main/java/com/glodblock/github/crossmod/opencomputers)

---
