# Thaumcraft — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Thaumcraft

OpenComputers is one of several options for automating Thaumcraft Infusion Altar operations (alongside AE2, Steve's Factory Manager, and GT pipes + Redstone). For complex infusion setups where outputs double as center items, OC scripts exist — shared via the [GTNH Discord](https://discord.com/channels/181078474394566657/1222007275246456902).

> Source: [GTNH Wiki - Infusion Automation](https://gtnh.miraheze.org/wiki/Infusion_Automation)

---

## Thaumcraft (Built-in Drivers)

OC ships with built-in drivers for Thaumcraft blocks.

### Aspect Container (`aspect_container`)

Any Thaumcraft block implementing `IAspectContainer` (e.g. Warded Jars, Alembics) is automatically exposed as an `aspect_container` component.

| Method | Description |
| --- | --- |
| `getAspects()` | Get a table of all aspects stored |
| `getAspectCount(name)` | Get amount of a specific aspect (lowercase name) |

### Infusion Matrix (`infusion_matrix`)

The Thaumcraft Infusion Matrix (infusion altar core) is exposed as an `infusion_matrix` component.

| Method | Description |
| --- | --- |
| `isActive()` | Whether the matrix is active |
| `isCrafting()` | Whether the matrix is currently crafting |
| `getInstability()` | Get current instability level |
| `getSymmetry()` | Get current symmetry value |

> Source: [OpenComputers source - thaumcraft integration](https://github.com/GTNewHorizons/OpenComputers/tree/master/src/main/scala/li/cil/oc/integration/thaumcraft)

---
