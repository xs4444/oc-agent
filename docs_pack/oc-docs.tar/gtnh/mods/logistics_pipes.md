# Logistics Pipes — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Logistics Pipes

Logistics Pipes provides OpenComputers components on its blocks plus CC-driven pipe modules:

### OC Components

- **`logisticspipe`** — Exposed by every Logistics Pipe tile entity (`LogisticsTileGenericPipe`). Provides `getPipe()`, returning a wrapped reference to the pipe (exposing its computer API).
- **`logisticssolidblock`** — Exposed by Logistics Solid blocks (`LogisticsSolidTileEntity`, e.g. the security station and crafting table). Provides `getBlock()`.

### CC Modules

- **CC Based QuickSort** — A pipe module that requires OpenComputers (or ComputerCraft) for functionality (instead of a built-in GUI), allowing precise control over item sorting.
- **CC ItemSink** — Filters items based on all known types in the system plus OpenComputers' own item database system. Has no fixed type, enabling dynamic filtering.
- **CC Remote Control Upgrade** — The actual upgrade item is the *CC Remote Control Upgrade* (`CCRemoteControlUpgrade`), a ComputerCraft-driven upgrade. It gates the `getPipeForUUID()` command, which returns the pipe belonging to a router UUID. There is **no** "CC Control Upgrade"; that name does not exist in the source.

> Source: [GTNH Wiki - Logistics Pipes](https://gtnh.miraheze.org/wiki/Logistics_Pipes)

---
