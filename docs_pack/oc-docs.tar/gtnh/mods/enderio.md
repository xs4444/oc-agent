# EnderIO — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## EnderIO (OC Conduit)

EnderIO provides its own OC integration via a dedicated **OC Conduit** — a conduit type that carries OpenComputers network signals through EnderIO conduit bundles, with support for **16 color-coded sub-channels** (one per DyeColor).

### How It Works

The OC Conduit implements `SidedEnvironment`, meaning each side of the conduit bundle can connect to OC components. Each connection direction can be assigned a **signal color** (using dye on the conduit), which maps to a separate OC network sub-channel. This allows routing different OC networks through a single conduit bundle without cross-talk.

### Key Features

- **16 sub-channels** — One per DyeColor (SILVER is default). Each color acts as a separate OC network.
- **Color-coded routing** — Apply dye to a conduit connection to set its channel. Use the Yeta Wrench to cycle colors.
- **Probe support** — The Wrench probe shows all active channels and connected nodes at a conduit location.
- **Animated textures** — Optional animated conduit textures (configurable in EnderIO config).

### Usage

```lua
-- The OC conduit does not expose a Lua component itself.
-- It transparently carries OC network signals between connected blocks.
-- Use dye to assign sub-channels to different conduit connections.
```

> Source: [EnderIO source - OC conduit](https://github.com/GTNewHorizons/EnderIO/tree/master/src/main/java/crazypants/enderio/conduit/oc)

---
