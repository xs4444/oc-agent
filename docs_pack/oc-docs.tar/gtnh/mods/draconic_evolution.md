# Draconic Evolution — OC Integration

> Part of [GTNH Cross-Mod Integration](../crossmod_integration.md)

## Draconic Evolution

An OC Adapter next to a **Draconic Reactor Stabilizer** exposes the `draconic_reactor` component, providing exact reactor data — superior to redstone comparators.

### API Methods

| Method | Description |
| --- | --- |
| `getReactorInfo()` | Returns table with `temperature`, `fieldStrength`, `maxFieldStrength`, `energySaturation`, `maxEnergySaturation`, `fuelConversion`, `maxFuelConversion`, `generationRate`, `fieldDrainRate`, `fuelConversionRate`, `status` |
| `chargeReactor()` | Initiates charging |
| `activateReactor()` | Activates the reactor once charged |
| `stopReactor()` | Initiates shutdown |

### Safety Shutdown Script

```lua
local component = require('component')
local reactor = component.draconic_reactor

local data = reactor.getReactorInfo()
local fuelConversion = data.fuelConversion
local maxFuelConversion = data.maxFuelConversion
local fuelConversionLevel = (fuelConversion / maxFuelConversion)

-- Auto-shutdown at 20% fuel conversion
if fuelConversionLevel > 0.20 then
  reactor.stopReactor()
end
```

Full automation scripts use threaded data polling, terminal dashboards, and configurable shutdown thresholds.

> Source: [GTNH Wiki - Draconic Reactor](https://gtnh.miraheze.org/wiki/Draconic_Reactor)

---
