# GTNH OpenComputers Guides

Guides and tutorials from the GTNH wiki, covering OpenComputers and related mods (OCGlasses, Computronics, etc.).

## Dedicated Guides

| Category | Page | Description |
| --- | --- | --- |
| Overview | [OpenComputers (GTNH)](open_computers.md) | OC integration with GTNH machines, ME system API reference |
| Cross-Mod | [Cross-Mod Integration](crossmod_integration.md) | 索引页 + 概念 — [25 个模组文档](crossmod_integration.md#mod-integration-index)按模组拆分 |
| Automation | [Item Stocking](item_stocking.md) | AE2 level-maintainer auto-stocking (⚠️ deprecated 2.5.0+) |
| Automation | [Crop Breeding](crop_breeding.md) | IC2 crop auto-tiering/statting/spreading (⚠️ deprecated 2.9+) |
| Automation | [Space Pumping](space_pumping.md) | Space Elevator pumping module auto-switching (GTNH 2.9) |
| HUD | [AR Glasses](ar_glasses.md) | OCGlasses HUD widget API reference |
| HUD | [NIDAS](nidas.md) | Multi-function HUD & automation software |
| HUD | [Power Display](power_display.md) | FoxHUD LSC power display via AR Glasses |

## GTNH Wiki Cross-References

The following GTNH wiki pages contain significant OC sections, documented in [Cross-Mod Integration](crossmod_integration.md):

| GTNH Wiki Page | OC Use Case | Mod |
| --- | --- | --- |
| [Automation](https://gtnh.miraheze.org/wiki/Automation) | OC as meta-automation tool overview | Umbrella |
| [Bacterial Vat](https://gtnh.miraheze.org/wiki/Bacterial_Vat) | Microcontroller fluid level control via `transposer` | GregTech |
| [Draconic Reactor](https://gtnh.miraheze.org/wiki/Draconic_Reactor) | Reactor monitoring + safety shutdown via `draconic_reactor` | Draconic Evolution |
| [Black Hole Containment](https://gtnh.miraheze.org/wiki/Pseudostable_Black_Hole_Containment_Field) | Full BHC automation (`gt_machine` + `redstone` + `transposer`) | GregTech |
| [SLAM](https://gtnh.miraheze.org/wiki/Shielded_Lagrangian_Annihilation_Matrix) | Antimatter/matter injection via `transposer` | GregTech |
| [Stargate](https://gtnh.miraheze.org/wiki/Stargate) | Programmatic Stargate dialing (pre-2.7 only method) | SGCraft |
| [Space Elevator](https://gtnh.miraheze.org/wiki/Space_Elevator) | Pumping module auto-switching | GregTech |
| [Applied Energistics 2](https://gtnh.miraheze.org/wiki/Applied_Energistics_2) | P2P tunnel attunement for OC | AE2 |
| [Logistics Pipes](https://gtnh.miraheze.org/wiki/Logistics_Pipes) | CC QuickSort / ItemSink / Control Upgrade | Logistics Pipes |
| [Forge of the Gods](https://gtnh.miraheze.org/wiki/Forge_of_the_Gods) | OC + AE2 crafting automation | GregTech |
| [Enhanced Lootbags](https://gtnh.miraheze.org/wiki/Enhanced_Lootbags) | OC item pool reference | Loot bags |
| [Infusion Automation](https://gtnh.miraheze.org/wiki/Infusion_Automation) | OC as infusion altar automation option | Thaumcraft |
| [Lapotronic Supercapacitor](https://gtnh.miraheze.org/wiki/Lapotronic_Supercapacitor) | LSC HUD via AR Glasses / NIDAS / OC Power Display | GregTech |

## Related Mods in GTNH

**OC family (19 mods with confirmed `li.cil.oc.api` imports):**

| Mod | Role | OC Integration |
| --- | --- | --- |
| **OpenComputers** | Core computation mod | Lua scripting, robots, drones, 100+ built-in drivers |
| **Computronics** | CC & OC add-on | 40+ drivers (GT, EnderIO, Railcraft, AE2, etc.), cards & boards |
| **OCGlasses** | OC add-on | AR Glasses HUD component (`glasses`) |
| **OpenPrinter** | OC add-on | In-game document printing |
| **OpenSecurity** | OC add-on | RFID, rack RAID, secure network cards |
| **AE2FluidCraft-Rework** | AE2 extension | Level maintainer, dual fluid interface, pattern editor drivers |
| **Display-Panels** | Nuclear Control 2 | Info panel, energy counter, thermal monitor, alarm drivers |
| **ThaumicTinkerer** | Thaumcraft extension | Arcane bore, arcane ear, brain in jar, essentia transport |
| **Draconic-Evolution** | Late-game tech | `draconic_reactor` component |
| **SGCraft** | Stargate mod | OC Stargate Interface block |
| **EnderIO** | Conduits & machines | OC Conduit (16 color-coded sub-channels) |
| **GT5-Unofficial** | GregTech | `GT-Data Server`, `gt_machine`/`LSC`/`gt_energyContainer` drivers |
| **LogisticsPipes** | Item routing | CC QuickSort, CC ItemSink, CC Control Upgrade |
| **OpenModularTurrets** | Defense | Turret base remote control (16 methods) |
| **Random-Things** | Utility | Online detector, notification interface, creative player interface |
| **AsieLib** | Library | OC wrench provider (compatibility) |
| **MatterManipulator** | Building tool | OC component item recognition |
| **Applied-Energistics-2** | ME networks | P2P tunnels, `me_controller`/`me_interface` APIs |
| **Nuclear-Control** | IC2 monitoring | Info panel, energy counter, thermal monitor |

> Source: [GTNH Wiki - OpenComputers](https://gtnh.miraheze.org/wiki/Open_Computers) · [GTNH Modlist](https://gtnh.miraheze.org/wiki/Modlist)
