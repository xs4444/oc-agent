# Interoperation with other Mods

OpenComputers interfaces with a lot of different mods, and many mods make use of OpenComputers' API, too. Here is a list of mods that are either supported by OC or support OC. No guarantee for completeness or correctness.

## Power
OpenComputers supports a good number of power systems.

- Applied Energistics 2
- Electical Age
  *ELN provides an adapter for OC.*
- Factorization
- Galacticraft
- IndustrialCraft 2 (Experimental and Classic)
- Mekanism
- Redstone Flux (Thermal Expansion, BuildCraft, EnderIO)
- Universal Electricity
- Simple Generators

## Redstone
OpenComputers supports the major bundled and wireless redstone systems.

- Project Red
- Minefactory's RedNET
- Redlogic
- Slimevoid's Wireless Redstone
- Wireless Redstone CBE

## Networking
OpenComputers can interface with the following mods to send network messages.

- ComputerCraft
  *Switch and Access Point blocks act as CC peripherals that emulate the CC modem API.*
- StargateTech 2
  *Abstract Bus card can be use to send and receive Abstract Bus messages.*

## Microblocks / Cover Systems
OpenComputers supports the following systems for covering cables.

- Forge MultiPart
- Immibis' Microblocks
  *Can also be used to cover keyboards.*

## Other Mods
A couple of mods support OC on their own, allowing computers to interact with some of their blocks, for example.

- Big Reactors
- BluePower (Sortron)
- Enhanced Portals 3
- LanteaCraft
- Logistics Pipes
- Nuclear Control 2
- RotaryCraft and ReactorCraft
- ThaumicTinkerer (Golem Connector)
- Networks Manager

## GTNH Cross-Mod Integration

For GTNH-specific integration guides covering GregTech machines, AE2 ME networks, Draconic Evolution reactors, Stargate dialing, Logistics Pipes modules, Thaumcraft infusion automation, and more — see [GTNH Cross-Mod Integration](gtnh/crossmod_integration.md).

Key GTNH integration points (19 mods with confirmed `li.cil.oc.api` imports):

**OC built-in drivers** (in `li.cil.oc.integration.*`):

- **GregTech** — `gt_machine`, `gt_energyContainer`, `LSC`, `transposer`; plus BEC Diode/IONode/Storage drivers
- **Applied Energistics 2** — `me_controller` / `me_interface` APIs, P2P tunnel attunement (`COMPUTER_MESSAGE`), full driver set (export/import/storage bus, upgrade, part interface)
- **IndustrialCraft 2** — `reactor` (nuclear reactor control), `crop` (IC2 crop stats), plus energy/mass-fab/teleporter drivers
- **Blood Magic** — `blood_altar` (capacity/blood/tier/progress), `master_ritual_stone` (owner/ritual/cooldown)
- **Thaumcraft** — `aspect_container` (aspect queries), `infusion_matrix` (active/crafting/instability/symmetry)
- **Thaumic Energistics** — `me_controller` reuse, plus essentia export/import/storage bus and block interface drivers
- **Forestry** — `bee_housing` (breeding data, species queries, mutation lists)
- **Vanilla** — `inventory` (getStack/transfer/compare), `fluid_handler`, `beacon`, `furnace`, `brewing_stand`, `command_block`, `mob_spawner`, etc.
- **Railcraft** — `DriverAnchor`, `DriverBoilerFirebox`, `DriverSteamTurbine`
- **BuildCraft** — `DriverControllable`, `DriverPipeTile`
- **CoFH / Thermal Expansion** — 8 drivers (energy handler/provider/receiver, redstone control, ender transport)
- **ComputerCraft** — `DriverComputerCraftMedia`, `DriverPeripheral`
- **Galacticraft** — `DriverWorldSensorCard`
- Plus: Ender Storage, Deep Storage Unit, StargateTech 2, Thermal Expansion (lamps), Tinkers' Mechworks, Avaritia Addons

**Mod-provided OC drivers:**

- **Computronics** — 40+ drivers: `gt_machine` (GT progress), EnderIO (13 drivers), Railcraft (8), BuildCraft, StorageDrawers, Redlogic, Mekanism, Factorization, AE2 (Spatial IO), Draconic Evolution (RF storage); plus OC items (CardBeep/Boom/FX/Noise/Sound/Spoof, BoardBoom/Capacitor/Light/Switch, MagicalMemory)
- **ThaumicTinkerer** — `arcanebore` (pickaxe/focus/radius/speed/fortune/silk), `DriverArcaneEar`, `DriverBrainInAJar`, `DriverDeconstructor`, `DriverEssentiaTransport`, `DriverIAspectContainer`
- **AE2FluidCraft-Rework** — `aelevelmaintainer` (slot config, crafting state), `DriverDualFluidInterface`, `DriverOCPatternEditor`
- **Display-Panels (Nuclear Control 2)** — `info_panel`, `DriverAdvancedInfoPanel`, `DriverAverageCounter`, `DriverEnergyCounter`, `DriverHowlerAlarm`, `DriverThermalMonitor`
- **OpenSecurity** — `RFIDReaderCardDriver`, `RackRaidDriver`, `SecureNetworkCardDriver`
- **OCGlasses** — `glasses` component (HUD widgets: 2D dot/triangle/rect/quad/text/item, 3D dot/line/triangle/cube/quad/text)
- **OpenPrinter** — Printer block (`li.cil.oc.api.network.Environment`)
- **OpenModularTurrets** — turret base (16 methods: target control, trust list, energy, redstone)
- **EnderIO** — OC Conduit (`SidedEnvironment`, 16 color-coded sub-channels)
- **GT5-Unofficial** — `GT-Data Server` (`SimpleComponent`, Data Orb/Stick storage)
- **Random-Things** — `onlinedetector`, `notificationinterface`, `creativeplayerinterface`
- **Draconic Evolution** — `draconic_reactor` (`getReactorInfo`, charge/activate/stop)
- **SGCraft (Stargate)** — OC Stargate Interface block for programmatic dialing
- **Logistics Pipes** — CC QuickSort, CC ItemSink, CC Control Upgrade
- **AsieLib** — OC wrench provider (compatibility layer)
- **MatterManipulator** — OC component item recognition for structure copying

See [GTNH Cross-Mod Integration](gtnh/crossmod_integration.md) for full API method tables and Lua examples.

## Addons
There are numerous addons that add blocks and items or drivers (support for other mods' blocks) specifically designed to work with OpenComputers. Please see [the according section on the forums](http://oc.cil.li/index.php?/forum/36-addons-mods/) and the [Addon page on this wiki](addon.md) for more information!

## Adapter
What was previously the OpenComponents addon is built into OC as of version 1.4. There are many drivers for the Adapter block to allow interfacing blocks from a number of other mods. It also allows using most of CC's peripherals, if CC is installed.

## Contents
