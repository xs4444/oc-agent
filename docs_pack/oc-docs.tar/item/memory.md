# Memory
 

 

 

Memory (RAM) comes in six tiers, with increasing sizes (each tier's size is configurable). They fall into the three item tiers like so: {1, 1.5}, {2, 2.5}, {3, 3.5}. Memory isn't really a component, since it does not provide any Lua callbacks, but it can be installed into [computer cases](../block/case.md) to increase the available RAM of the computer, which allows running more complex programs.

The Memory (Tier 1) is crafted using the following recipe:
  * 1 x Iron nugget/oreberry (with Tinker's Construct)
  * 2 x [Microchip (Tier 1)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)



The Memory (Tier 1.5) is crafted using the following recipe:
  * 1 x [Microchip (Tier 2)](materials.md)
  * 2 x [Microchip (Tier 1)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)



The Memory (Tier 2) is crafted using the following recipe:
  * 1 x Iron nugget/oreberry (with Tinker's Construct)
  * 2 x [Microchip (Tier 2)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)



The Memory (Tier 2.5) is crafted using the following recipe:
  * 1 x [Microchip (Tier 3)](materials.md)
  * 2 x [Microchip (Tier 2)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)



The Memory (Tier 3) is crafted using the following recipe:
  * 1 x Iron nugget/oreberry (with Tinker's Construct)
  * 2 x [Microchip (Tier 3)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)



The Memory (Tier 3.5) is crafted using the following recipe:
  * 3 x [Microchip (Tier 3)](materials.md)
  * 2 x [Microchip (Tier 2)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)



## Contents
