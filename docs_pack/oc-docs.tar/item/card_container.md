# Card Container
  

This upgrade provides a card slot supporting a card up the tier of the container. For example, a tier two card container can take a tier two card.

*Since version 1.3.*

The Card Container (Tier 1) is crafted using the following recipe:
  * 4 x Iron Ingot
  * 1 x Piston
  * 1 x Chest
  * 1 x [Microchip (Tier 1)](materials.md)
  * 1 x [Card Base](materials.md)


The Card Container (Tier 2) is crafted using the following recipe:
  * 4 x Iron Ingot
  * 1 x Piston
  * 1 x Chest
  * 1 x [Microchip (Tier 2)](materials.md)
  * 1 x [Card Base](materials.md)


The Card Container (Tier 3) is crafted using the following recipe:
  * 4 x Gold Ingot
  * 1 x Piston
  * 1 x Chest
  * 1 x [Microchip (Tier 2)](materials.md)
  * 1 x [Card Base](materials.md)


## Contents
