# Generator Upgrade
![](../media/items/generator_upgrade.png)

Can be used to generate energy from fuel on the go. Burns items to generate energy over time, based on their fuel value.

Note that fuel can only be inserted into the generator via [its API](../component/generator.md), so you'll have to charge your robot up to a certain level using a [charger block](../block/charger.md) first.

Per default the generator's efficiency is at 80% of a BuildCraft Stirling Engine, i.e. it consumes the fuel at the same pace a Stirling Engine would, but only outputs 80% of the energy a Stirling Engine would.

The Generator Upgrade is crafted using the following recipe:
  * 4 x Iron Ingot
  * 1 x Piston
  * 1 x [Printed Circuit Board](materials.md)
  * 2 x [Microchip (Tier 1)](materials.md)
![](../media/recipes/items/generatorupgrade.png)

## Contents
