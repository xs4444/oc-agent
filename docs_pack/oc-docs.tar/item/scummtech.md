# Scummtech


Scummtech, Inc. is not a real item — it is the fictional vendor name reported by the [MFU](mfu.md) in its device info (`DeviceAttribute.Vendor`). It is an easter egg reference to LucasArts' SCUMM engine and the Monkey Island games.

Items built by Scummtech, Inc. include:
  * [MFU](mfu.md) — the wireless linking upgrade

## Contents
