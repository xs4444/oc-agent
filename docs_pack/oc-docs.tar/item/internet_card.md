# Internet Card


This card provides access to 'the interwebs'. It allows making HTTP requests and opening TCP sockets, unless disabled in the config. See the [Internet API](../api/internet.md).

Note that the Internet Card is a Tier 2 card and requires an available Tier 2 (or higher) slot to use.

The Internet Card is crafted using the following recipe:
  * 1 x [Interweb](materials.md)
  * 1 x Obsidian
  * 1 x [Microchip (Tier 2)](materials.md)
  * 1 x Redstone Torch
  * 1 x [Card Base](materials.md)


## Contents
