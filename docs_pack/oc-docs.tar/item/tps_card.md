# TPS Card
![](../media/items/tps_card.png)

> GTNH fork addition

The TPS Card is a card-slot item that provides the [TPS Card](../component/tps_card.md) component, exposing server performance information to computers, robots, and drones: tick times per dimension, overall TPS, and counts of loaded entities, tile entities and chunks.

Sneak-right-clicking while holding the card (as an OP) binds it to the current player; binding is required for location-sensitive calls such as `getCoordinatesForEntityClassInDim`.

The TPS Card is crafted using the following recipe:
  * 1 x [Card Base](materials.md#card-base)
  * 1 x [Microchip (Tier 1)](materials.md#microchips)
  * 1 x Clock
  * 1 x [Analyzer](analyzer.md)

![](../media/recipes/items/tpscard.png)

## Contents
