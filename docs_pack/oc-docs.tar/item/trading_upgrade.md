# Trading Upgrade
![](../media/items/trading_upgrade.png)

The Trading Upgrade enables automatic trading with merchants, such as villagers. It is used in agents such as [robots](../block/robot.md) and [drones](drone.md) and provides the [Trading](../component/trading.md) component, which can identify trades offered by nearby merchants, retrieve information on individual trade offers, and perform trades.

Merchants within a range of 8 blocks (configurable via `misc.tradingRange`) are detected.

The Trading Upgrade is crafted using the following recipe:
  * 2 x Gold Ingot
  * 2 x Emerald
  * 1 x Chest
  * 1 x Dropper
  * 1 x Piston (normal or sticky)
  * 1 x [Microchip (Tier 2)](materials.md#microchips)
  * 1 x [Printed Circuit Board](materials.md#printed-circuit-board)

![](../media/recipes/items/tradingupgrade.png)

## Contents
