# Mountable Disk Drive


This device is functionally equivalent to a regular [Disk Drive](../block/disk_drive.md), except that it is installed in a [server rack](../block/server_rack.md). It provides the [Drive](../component/drive.md) component to the server it is mounted in.

The Mountable Disk Drive is crafted using the following recipe:
  * 4 x Obsidian
  * 2 x Iron Bars
  * 1 x [Disk Drive](../block/disk_drive.md)
  * 1 x [Microchip (Tier 1)](materials.md#microchips)
  * 1 x [Printed Circuit Board](materials.md#printed-circuit-board)



## Contents
