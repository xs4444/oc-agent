# Chunkloader Upgrade


This upgrade allows robots and drones to act as a one-chunk chunkloader, allowing them to continue to operate even when no player is nearby / some other chunkloader is active. Note that this upgrade consumes energy when active - it provides [a component](../component/chunkloader.md) that can be used enable or disable it.

The default condition for the chunkloader after installation in a robot is **enabled**. Use the  [component.setActive()](../component/chunkloader.md) callback to change the status.

*Since version 1.3.*

The Chunkloader Upgrade is crafted using the following recipe:
  * 2 x Obsidian
  * 2 x Gold ingot
  * 1 x Eye of Ender
  * 1 x Glass
  * 2 x [Microchip (Tier 3)](materials.md)
  * 1 x [Printed Circuit Board](materials.md)


## Contents
