# ME Upgrade
![](../media/items/me_upgrade1.png)![](../media/items/me_upgrade2.png)![](../media/items/me_upgrade3.png)

> GTNH fork addition

ME Upgrades (Tiers 1, 2 and 3) are Applied Energistics 2 integration upgrades for [robots](../block/robot.md) and [drones](drone.md). They provide the `upgrade_me` component, allowing agents to interact directly with an AE2 network: sending and requesting items and fluids, checking whether the network link is established, and accessing the linked storage.

Higher tiers provide more capabilities and larger transfer limits.

The ME Upgrades are registered by the AE2 integration module. They have no crafting recipe of their own — see the [Applied Energistics 2 integration](../gtnh/crossmod_integration.md) page for details.

## Contents
