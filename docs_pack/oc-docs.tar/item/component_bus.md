### Component Bus


A component bus has similar functionality as a CPU, it controls the number of components that can be connected to a computer before it will not start anymore / crash. It does not replace a CPU however. At the time of writing, component buses can only be built into servers, allowing them to support a much larger number of concurrent components than normal computers.

The Component Bus (Tier 1) is crafted using the following recipe:
  * 4 x Iron nugget/oreberry
  * 1 x Redstone dust
  * 1 x [Microchip (Tier 1)](materials.md)
  * 1 x [Control Unit](materials.md)
  * 1 x [Printed Circuit Board](materials.md)


The Component Bus (Tier 2) is crafted using the following recipe:
  * 4 x Gold nugget/oreberry
  * 1 x Redstone dust
  * 1 x [Microchip (Tier 2)](materials.md)
  * 1 x [Control Unit](materials.md)
  * 1 x [Printed Circuit Board](materials.md)


The Component Bus (Tier 3) is crafted using the following recipe:
  * 4 x Emerald
  * 1 x Redstone dust
  * 1 x [Microchip (Tier 3)](materials.md)
  * 1 x [Control Unit](materials.md)
  * 1 x [Printed Circuit Board](materials.md)


## Contents
