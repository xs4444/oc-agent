# Network Debugger
![](../media/items/debugger.png)

The Network Debugger is a developer tool used to output debug information about OpenComputers' internal network grid. Right-clicking a block that hosts a network environment connects the debugger to its node and logs detailed information about the node, its connections and any messages sent over it to the log.

Its tooltip warns: *"Can be used to output debug information on OC's internal network grid. Only use if so instructed by a dev."*

The Network Debugger has no crafting recipe — it is a debug-only tool.

## Contents
