# Default Vendor
![](../media/items/default_vendor.png)

"Default Vendor" refers to the default vendor name reported by OpenComputers components and blocks in their device info (`DeviceAttribute.Vendor`). It is not a real item.

The default vendor string is *"MightyPirates GmbH & Co. KG"* — a tongue-in-cheek reference to the OpenComputers development team. It appears in `getDeviceInfo()` results for most OC blocks and components.

## Contents
