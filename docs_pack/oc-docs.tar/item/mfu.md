# MFU


The MFU ("Multi-Functional Upgrade", exact meaning unknown) is a Tier 3 upgrade that acts as a remote [adapter](../block/adapter.md). Sneak-click on any side of any block to bind it to that position, then install it in an [adapter](../block/adapter.md) nearby — the upgrade then behaves as if the adapter was placed right next to the bound side.

The connection range is very limited (16 blocks by default, configurable via `misc.mfuRange`), and keeping the remote connection active consumes energy. Its device info lists the vendor as [Scummtech, Inc.](scummtech.md) — an easter egg.

The MFU is crafted using the following recipe:
  * 2 x [Chamelium](materials.md#chamelium)
  * 2 x Lapis Lazuli
  * 2 x [Linked Card](linked_card.md)
  * 1 x [Adapter](../block/adapter.md)



## Contents
