# Present


The Present ("A little something...") is an easter egg item that is occasionally obtained as a bonus when crafting OpenComputers items during certain times of the year (e.g. Christmas, New Year, Valentine's Day, April 22nd, May 1st, October 3rd, December 14th), depending on the `presentChance` config option. It does not show up in the creative item list and has no crafting recipe of its own.

Right-clicking a Present consumes it and grants a random craftable OpenComputers item, weighted by how useful it is — the rarer the item, the lower its chance of dropping.

## Contents
