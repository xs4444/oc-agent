# Abstract Bus Card


This card allows [computers](../block/computer_case.md), [servers](server.md), [robots](../block/robot.md) and [microcontrollers](microcontrollercase.md) to interact with StargateTech 2's Abstract Bus network, providing the [Abstract Bus](../component/abstract_bus.md) component. Incoming abstract bus messages are converted to signals that are injected into the machine.

The card only shows up in the item list when StargateTech 2 is installed, and fits into a regular card slot.

The Abstract Bus Card is crafted using the following recipe:
  * 1 x [Card Base](materials.md#card-base)
  * 1 x StargateTech 2 Abstract Bus Cable
  * 1 x StargateTech 2 Naquadah



## Contents
