# NBT API

> **GTNH fork addition:** The `nbt` library is not part of vanilla OpenComputers. It was added in the GTNH fork (2026-06, PR #194) together with table/NBT support on the [Data Card](../component/data.md) component, for AE2 integration.

The NBT API provides helpers for working with NBT (Named Binary Tag) data structures returned by components, in particular the NBT methods of the Data Card (`decodeNBT`/`encodeNBT`). NBT values are represented as tables with `__nbt_type` and `__value` fields; this library wraps them in proxies that behave like ordinary Lua tables.

- `nbt.wrap(data:table): table`
  Wraps an NBT tag table into a proxy table that behaves like a normal Lua table: reading/writing fields, `pairs` iteration and length (`#`) work transparently. Wrapped tables are cached per source tag.
- `nbt.unwrap(data:table): table`
  Unwraps a proxy table back into its raw NBT tag table representation. Useful before passing data back to components.
- `nbt.patch(component:table): table`
  Patches a component proxy (e.g. the Data Card) so that returned NBT values are automatically wrapped, and values passed to `encodeNBT` are automatically unwrapped. Returns the proxy. The proxy is patched only once.

## Proxy methods

On a wrapped NBT tag (a proxy returned by `nbt.wrap`), the following methods are available to set typed values (the key `k` is a string key on a compound, or an index on a list):

- `proxy:set_string(k, v:string)`
- `proxy:set_boolean(k, v:boolean)`
- `proxy:set_byte(k, v:number)`
- `proxy:set_short(k, v:number)`
- `proxy:set_int(k, v:number)`
- `proxy:set_long(k, v:number)`
- `proxy:set_float(k, v:number)`
- `proxy:set_double(k, v:number)`
- `proxy:set_byte_array(k, v:table)`
- `proxy:set_int_array(k, v:table)`
- `proxy:set_list(k, v:table)`
- `proxy:set_compound(k, v:table)`

Setting a new key without a typed setter requires passing a table with `__nbt_type` and `__value` fields (or a boolean, which is stored as a byte).

## Example

```lua
local nbt = require('nbt')
local dataCard = component.data
nbt.patch(dataCard)

-- Decode NBT from the Data Card, work with it as a normal table
local tag = dataCard.decodeNBT(encodedString)
tag.name = "Hello"          -- plain assignment
tag:set_int("count", 42)    -- typed assignment
print(tag.name, tag.count)

-- Encode it back (patch() auto-unwraps)
dataCard.encodeNBT(tag)
```

> Source: [OpenComputers source - assets/opencomputers/loot/openos/lib/nbt.lua](https://github.com/GTNewHorizons/OpenComputers/blob/master/src/main/resources/assets/opencomputers/loot/openos/lib/nbt.lua)
