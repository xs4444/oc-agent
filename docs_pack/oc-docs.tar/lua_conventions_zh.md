# Lua 代码规范
  * 保持代码风格一致。
  * 使用两个空格缩进。并且合理使用缩进。
  * 尝试将单行代码限制在80字符以内。
  * 不要在大括号/花括号及其内容间增加不必要的空格。
  * 调用函数时不要省略括号，哪怕括号没必要。
  * 变量名只代表它们自己，不要添加类型标记，即不要用匈牙利命名法。
  * 最好按字母顺序排列require（强迫症！）
  * 编写注释时请放宽心。文件加载完成后由于大量使用注释占用的额外内存会很快释放。
  * 如果你需要验证参数，请使用内建的checkArg函数。尽量产生同类报错信息是好事！其用法为`checkArg(n, value, type1,...)`，n是参数的编号，value是参数的值，type1和后面的内容为允许的变量类型，变量类型可通过`type(value)` 获得。报错信息中，前文的编号以如下方式出现：“bad argument #n (type1 expected, got type(value))”。例如，若要求第一个参数为数字，你可以写 `checkArg(1, arg, "number")`。

不好的代码：
```lua
function f(sArg1 , ... )
   assert(type(sArg1)== "string", "me wants a strign!")
    if sArg1 then
        local nResult = 1
        -- 做更多任务
        return nResult
  end
end
if  f ( "a" )  ==1 then
print"asd"
end
```

好代码：
```lua
function f(name, ...)
  checkArg(1, name, "string")
  if name then
    local result = 1
    -- 我们将非欧利几得空间的B-样条算法外推来得出潜在的失败概率
    return result
  end
end
if f("a") == 1 then
  print("asd")
end
```

## 目录
