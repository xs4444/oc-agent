# Component: Drone

Provided by [Drones](../item/drone.md).

Drones are mobile [robots](../block/robot.md), thinned down to the bare essentials, similar to a [microcontroller](../block/microcontroller.md).
They are more nimble than robots.
Component name: `drone`.

Callbacks:

### Base Methods

- `getStatusText():string`
  Get the status text currently being displayed in the GUI.
- `setStatusText(value:string):string`
  Set the status text to display in the GUI, returns new value.
- `getLightColor():number`
  Get the current color of the flap lights as an integer encoded RGB value (0xRRGGBB).
- `setLightColor(value:number):number`
  Set the color of the flap lights to the specified integer encoded RGB value (0xRRGGBB).
- `move(dx:number, dy:number, dz:number)`
  Change the target position by the specified offset.
- `getOffset():number`
  Get the current distance to the target position.
- `getVelocity():number`
  Get the current velocity in m/s.
- `getMaxVelocity():number`
  Get the maximum velocity, in m/s.
- `getAcceleration():number`
  Get the currently set acceleration.
- `setAcceleration(value:number):number`
  Try to set the acceleration to the specified value and return the new acceleration.
- `name():string`
  Get the name of the agent.
- `swing(side:number[, face:number=side[, sneaky:boolean=false]]):boolean, string`
  Perform a 'left click' towards the specified side. The `face` allows a more precise click calibration, and is relative to the targeted block space. Returns `true` and the type of thing hit (`entity`, `block`, `fire`, ...) on success.
- `use(side:number[, face:number=side[, sneaky:boolean=false[, duration:number=0]]]):boolean, string`
  Perform a 'right click' towards the specified side. The `face` allows a more precise click calibration, and is relative to the targeted block space.
- `place(side:number[, face:number=side[, sneaky:boolean=false]]):boolean`
  Place a block towards the specified side. The `face` allows a more precise click calibration, and is relative to the targeted block space.
- `detect(side:number):boolean, string`
  Checks the contents of the block on the specified side and returns the findings.

### Internal Inventory Methods

- `inventorySize():number`
  The size of this device's internal inventory.
- `select([slot:number]):number`
  Get the currently selected slot; set the selected slot if specified. Returns the (1-based) selected slot.
- `count([slot:number]):number`
  Get the number of items in the specified slot, otherwise in the selected slot.
- `space([slot:number]):number`
  Get the remaining space in the specified slot, otherwise in the selected slot.
- `compareTo(otherSlot:number[, checkNBT:boolean=false]):boolean`
  Compare the contents of the selected slot to the contents of the specified slot.
- `transferTo(toSlot:number[, amount:number]):boolean`
  Move up to the specified amount of items from the selected slot into the specified slot.

### External Inventory Methods

- `compare(side:number[, fuzzy:boolean=false]):boolean`
  Compare the block on the specified side with the one in the selected slot. Returns `true` if equal.
- `drop(side:number[, count:number=64]):boolean`
  Drops items from the selected slot towards the specified side.
- `suck(side:number[, count:number=64]):boolean`
  Suck up items from the specified side. Returns the number of items sucked, or `false` if none could be sucked.

### Tank Methods

- `tankCount():number`
  The number of tanks installed in the device.
- `selectTank([index:number]):number`
  Select a tank and/or get the number of the currently selected tank.
- `tankLevel([index:number]):number`
  Get the fluid amount in the specified or selected tank.
- `tankSpace([index:number]):number`
  Get the remaining fluid capacity in the specified or selected tank.
- `compareFluidTo(index:number):boolean`
  Compares the fluids in the selected and the specified tank. Returns `true` if equal.
- `transferFluidTo(index:number[, count:number=1000]):boolean`
  Move the specified amount of fluid from the selected tank into the specified tank.
- `compareFluid(side:number[, tank:number]):boolean`
  Compare the fluid in the selected tank with the fluid in the specified tank on the specified side. Returns `true` if equal.
- `drain(side:number[, amount:number=1000]):boolean, number or string`
  Drains the specified amount of fluid from the specified side. Returns the amount drained, or an error message.
- `fill(side:number[, amount:number=1000]):boolean, number or string`
  Eject the specified amount of fluid to the specified side. Returns the amount ejected or an error message.

## Contents
