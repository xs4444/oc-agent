# Component: Serial Port
This component is exposed by an [adapter](../block/adapter.md) when it is connected to a [TIS-3D](https://mods.curseforge.com/minecraft/mc-mods/tis-3d) serial interface, bridging the two serial protocols. It buffers data in both directions (up to 128 values each) so TIS-3D modules can talk to OpenComputers computers and vice versa.

> **Note:** This component is a GTNH fork addition (TIS-3D integration), not present in vanilla OpenComputers.

Component name: `serial_port`.
Callbacks:

- `setReading(reading:boolean)`
  Enable or disable reading: while enabled, values received from the connected TIS-3D serial port are buffered and can be read with `read()`.
- `read():number`
  Dequeue the next buffered value received from the connected TIS-3D serial port. Returns `nil` if the read buffer is empty.
- `write(value:number):boolean`
  Queue a value (0-65535, stored as a short) to be sent to the connected TIS-3D serial port. Returns `false` if the write buffer is full.

## Contents
