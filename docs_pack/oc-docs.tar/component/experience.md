# Component: Experience
This component is provided by the [experience upgrade](../item/experience_upgrade.md).

Component name: `experience`.
Callbacks:

- `level():number`
  Gets the level of experience stored in the experience upgrade.
- `consume():boolean`
  Tries to consume an enchanted item (or an experience bottle) from the selected slot to add experience to the upgrade.

> **GTNH fork note:** `consume` is a GTNH fork addition, not present in vanilla OpenComputers.

---
