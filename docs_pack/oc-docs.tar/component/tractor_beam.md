# Component: Tractor Beam
This is the component provided by the [Tractor Beam Upgrade](../item/tractor_beam_upgrade.md).

Component name: `tractor_beam`.
Callbacks:

- `suck(): boolean`
  Tries to pick up a random item in the robots' vicinity (a 9x9 area with the robot at its center).

---
