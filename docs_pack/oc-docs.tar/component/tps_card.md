# Component: TPS Card
This component is provided by the TPS card (tpsCard), a card that reports performance metrics of the server it runs on, such as tick times, TPS, and loaded chunks, tile entities and entities.

> **Note:** This component is a GTNH fork addition, not present in vanilla OpenComputers.

Component name: `tps_card`.
Callbacks:

- `getTickTimeInDim(dimension:number):number`
  Get the milliseconds taken by the specified dimension's tick.
- `getOverallTickTime():number`
  Get the overall tick time of the server.
- `getAllDims():table`
  Returns a table with index corresponding to the dimension id and value at the index being the dimension name.
- `getAllTickTimes():table`
  Returns a table with index corresponding to the dimension id and value at the index being the tick time taken by the dimension.
- `getNameForDim(dimension:number):string`
  Get the name corresponding to the specified dimension.
- `convertTickTimeIntoTps(time:number):number`
  Takes a number (in ms) and returns the actual TPS corresponding to it. The result is capped at 20 TPS.
- `getOverallTileEntitiesLoaded():number`
  Get the overall amount of tile entities loaded in memory.
- `getOverallChunksLoaded():number`
  Get the overall amount of chunks loaded in memory.
- `getOverallEntitiesLoaded():number`
  Get the overall amount of entities loaded in memory.
- `getOverallDimsLoaded():number`
  Get the number of dimensions loaded.
- `getEntitiesListForDim(dimension:number):table`
  Returns a table where the index is the name of the entity class, and the value the amount of entities in that dimension.
- `getTileEntitiesListForDim(dimension:number):table`
  Returns a table where the index is the name of the tile entity class, and the value the amount of tile entities in that dimension.
- `getChunksLoadedForDim(dimension:number):number`
  Get the amount of chunks loaded in that dimension.
- `getCoordinatesForEntityClassInDim(className:string, dimension:number):table`
  Returns a table with all the coordinates of the entities matching the class name in that dimension. Requires the card to have access rights to the player it is bound to.

## Contents
