# Component: Relay
This component is provided by the [relay](../block/relay.md) block and allows computers attached to it to change the strength of the signal used to relay wireless messages and whether it acts as a wireless repeater.

Component name: `relay`.
Callbacks:

- `getStrength():number`
  Get the signal strength (range) used when relaying messages.
- `setStrength(strength:number):number`
  Set the signal strength (range) used when relaying messages. Returns the new strength.
- `isRepeater():boolean`
  Get whether the relay currently acts as a repeater (resend received wireless packets wirelessly).
- `setRepeater(enabled:boolean):boolean`
  Set whether the relay should act as a repeater. Returns the new state.

## Contents
