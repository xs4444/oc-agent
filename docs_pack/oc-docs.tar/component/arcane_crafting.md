# Component: Arcane Crafting Upgrade
This component is provided by the arcane crafting upgrade and allows a robot to craft items from its inventory using both normal and arcane (Thaumcraft) recipes. Requires Thaumcraft to be installed.

The robot considers the top-left area of its inventory the crafting area, similar to the [crafting upgrade](crafting.md). Arcane crafting additionally requires a wand with sufficient Vis; the wand must be placed in the robot's first inventory slot, and the robot must be standing in front of a charged Thaumcraft arcane workbench.

Component name: `arcane_crafting`.
Callbacks:

- `craft([count:number]):boolean, number, string`
  Tries to craft the specified number of items in the top left area of the inventory using both normal and arcane recipes. Returns `true` if at least one item was crafted, the number of items crafted, and an error message on failure (if any).
- `craftNormal([count:number]):boolean, number, string`
  Tries to craft the specified number of items using only vanilla crafting recipes.
- `craftArcane([count:number]):boolean, number, string`
  Tries to craft the specified number of items using only Thaumcraft arcane recipes.

## Contents
