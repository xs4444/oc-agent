# Component: Beekeeper Upgrade
This component is provided by the beekeeper upgrade (tier 2 upgrade) and allows a robot or drone to manage Forestry apiaries and other bee housings: swapping queens and drones, checking breeding progress, analyzing bees, and managing industrial apiary upgrades.

Component name: `beekeeper`.
Callbacks:

- `swapQueen(side:number):boolean`
  Swap the queen from the selected slot with the apiary at the specified side.
- `swapDrone(side:number):boolean`
  Swap the drone from the selected slot with the apiary at the specified side.
- `getBeeProgress(side:number):number`
  Get the current progress percent for the apiary at the specified side. Returns `false` if no bee housing is found.
- `canWork(side:number):boolean`
  Checks if the current bee in the apiary at the specified side can work now.
- `analyze(honeyslot:number):boolean`
  Analyze the bee in the selected slot, using honey from the specified slot.
- `addIndustrialUpgrade(side:number[, amount:number]):number`
  Tries to add `amount` (default: all) industrial upgrades from the selected slot to the industrial apiary at the given side. Returns the number of upgrades added.
- `getIndustrialUpgrade(side:number, slot:number):table`
  Get the industrial upgrade in the given slot of the industrial apiary at the given side.
- `removeIndustrialUpgrade(side:number, slot:number[, amount:number]):boolean`
  Remove industrial upgrade(s) from the given slot of the industrial apiary at the given side.

## Contents
