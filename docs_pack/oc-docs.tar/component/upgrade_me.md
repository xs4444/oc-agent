# Component: ME Upgrade
This component is provided by the ME upgrade (`me_upgrade1`, `me_upgrade2`, `me_upgrade3`), a wireless link upgrade that allows a robot or drone to interact with an Applied Energistics 2 ME network. The upgrade must be linked to an AE2 security terminal to grant access to the network. The tier of the upgrade determines its wireless range multiplier.

> **Note:** This component is a GTNH fork addition (AE2 integration), not present in vanilla OpenComputers.

Component name: `upgrade_me`.
Callbacks:

- `sendItems([amount:number]):number`
  Transfer the selected items (up to `amount`, default 64) from the selected inventory slot into the linked ME system. Returns the number of items transferred.
- `requestItems(database:address, entry:number[, amount:number]):number` OR `requestItems(detail:table):number`
  Get items from the linked ME system into the currently selected slot. The items can either be described by a database address and entry, or by a detail table with keys `name` (string, required), `damage` (number, optional), `size` (number, optional), `id` (number, optional). Returns the number of items extracted.
- `sendFluids([amount:number]):number`
  Transfer the selected fluid (up to `amount` millibuckets, default the tank capacity) from the selected tank into the linked ME system. Returns the amount transferred.
- `requestFluids(database:address, entry:number[, amount:number]):number` OR `requestFluids(detail:table):number`
  Get fluid from the linked ME system into the currently selected tank. The fluid can either be described by a database address and entry, or by a detail table with keys `name` (string, required), `size` (number, optional, 1000 = 1 bucket), `id` (number, optional). Returns the amount filled.
- `isLinked():boolean`
  Returns `true` if the card is linked to your AE network.

### Network Control Methods

- `getCpus():table`
  Get a list of tables representing the available CPUs in the network. Each table contains the keys `name`, `storage`, `coprocessors`, `busy` and `cpu` (a CPU object, see below).
- `getCraftable(detail:table, type:string):table`
  Get a known recipe. This can be used to issue crafting requests. Returns a Craftable object, or `null` if the item is not craftable.
- `getCraftables([filter:table]):table`
  Get a list of known item recipes. These can be used to issue crafting requests.
- `getItemsInNetwork([filter:table]):table`
  Get a list of the stored items in the network.
- `getItemInNetwork(name:string or id:number[, damage:number[, nbt:string]]):table` OR `getItemInNetwork(detail:table):table`
  Retrieves the stored item in the network by its unlocalized name. For the first format, `nbt` expects an SNBT string.
- `getItemsInNetworkById(filter:table):table`
  Get a list of the stored items in the network matching the filter. The filter is an array of item IDs (numbers or strings).
- `getFluidInNetwork([name:string]):table` OR `getFluidInNetwork(detail:table):table`
  Get a list of the stored fluids in the network.
- `getFluidsInNetwork():table`
  Get a list of the stored fluids in the network.
- `allItems():userdata`
  Get an iterator object for the list of the items in the network.
- `store(filter:table, dbAddress:string[, startSlot:number[, count:number]]):boolean`
  Store items in the network matching the specified filter in the database with the specified address.
- `getAvgPowerInjection():number`
  Get the average power injection into the network.
- `getAvgPowerUsage():number`
  Get the average power usage of the network.
- `getIdlePowerUsage():number`
  Get the idle power usage of the network.
- `getMaxStoredPower():number`
  Get the maximum stored power in the network.
- `getStoredPower():number`
  Get the stored power in the network.
- `setFluidEventSubscription(enabled:boolean)`
  Enable or disable subscription to the `network_fluid_changed` event.
- `isFluidEventSubscription():boolean`
  Returns whether the `network_fluid_changed` event subscription is currently enabled.
- `setItemEventSubscription(enabled:boolean)`
  Enable or disable subscription to the `network_item_changed` event.
- `isItemEventSubscription():boolean`
  Returns whether the `network_item_changed` event subscription is currently enabled.

### Craftable Object

A Craftable object is returned by `getCraftable` and `getCraftables`. It represents a known crafting recipe.

- `getStack():table`
  Returns the item stack representation of the crafting result.
- `request([amount:number[, prioritizePower:boolean[, cpuName:string]]]):userdata`
  Requests the item to be crafted, returning a Crafting Status object that allows tracking the crafting status.

### Crafting Status Object

The object returned by `request` can be used to track a crafting request.

- `isComputing():boolean`
  Get whether the crafting request is currently computing.
- `hasFailed():boolean`
  Get whether the crafting request has failed.
- `isCanceled():boolean`
  Get whether the crafting request has been canceled.
- `isDone():boolean`
  Get whether the crafting request is done.

### CPU Object

The `cpu` value in the tables returned by `getCpus` exposes the following methods:

- `cancel():boolean`
  Cancel this CPU current crafting job.
- `isActive():boolean`
  Is the CPU active?
- `isBusy():boolean`
  Is the CPU busy?
- `activeItems():table`
  Get currently crafted items.
- `pendingItems():table`
  Get pending items.
- `storedItems():table`
  Get stored items.
- `finalOutput():table`
  Get crafting final output.

## Contents
