# Component: Configurator
This component is provided by the configurator upgrade and allows configuring [EnderIO](https://www.curseforge.com/minecraft/mc-mods/ender-io) conduits from OpenComputers. Requires EnderIO to be installed. It can be used in adapters, drones, robots and microcontrollers.

Component name: `configurator`.
Callbacks:

- `getConduitConfiguration(side:number, conduitDirection:number):table`
  Get the conduit configuration at the specified conduit direction. Returns a table with information about the conduit bundle, such as whether it has a facade (`HasFacade`) and, depending on the conduit type present, an `ItemConduit`, `LiquidConduit` and/or `RedstoneConduit` sub-table with the current settings (colors, connection mode, filters, priority, etc.).
- `setItemConduitColor(side:number, conduitDirection:number, isInput:boolean, color:string):boolean`
  Set the item conduit input or output color (`isInput` selects which one).
- `setItemConduitOutputPriority(side:number, conduitDirection:number, priority:number):boolean`
  Set the item conduit output priority.
- `setItemConduitFilter(side:number, conduitDirection:number, database:string, dbSlot:number, filterIndex:number, isInput:boolean):boolean`
  Set the item stored in the specified slot of the given database as the item conduit input or output filter at the given filter index.
- `setItemConduitConnectionMode(side:number, conduitDirection:number, mode:string):boolean`
  Set the item conduit connection mode. Valid modes: `IN_OUT`, `INPUT`, `OUTPUT`, `DISABLED`, `NOT_SET`.
- `setItemConduitExtractionRedstoneColor(side:number, conduitDirection:number, color:string):boolean`
  Set the item conduit extraction redstone signal color.
- `setItemConduitExtractionRedstoneMode(side:number, conduitDirection:number, mode:string):boolean`
  Set the item conduit extraction redstone signal mode. Valid modes: `IGNORE`, `ON`, `OFF`, `NEVER`.
- `setEnderLiquidConduitFilter(side:number, conduitDirection:number, fluid:string, blacklist:boolean, isInput:boolean[, filterIndex:number]):boolean`
  Set the filter of an Ender liquid conduit for the given fluid (by registry name).
- `setEnderLiquidConduitColor(side:number, conduitDirection:number, isInput:boolean, color:string):boolean`
  Set the color of an Ender liquid conduit input or output.
- `setLiquidConduitConnectionMode(side:number, conduitDirection:number, mode:string):boolean`
  Set the liquid conduit connection mode. Valid modes: `IN_OUT`, `INPUT`, `OUTPUT`, `DISABLED`, `NOT_SET`.
- `setLiquidConduitExtractionRedstoneColor(side:number, conduitDirection:number, color:string):boolean`
  Set the fluid conduit extraction redstone signal color.
- `setLiquidConduitExtractionRedstoneMode(side:number, conduitDirection:number, mode:string):boolean`
  Set the fluid conduit extraction redstone signal mode. Valid modes: `IGNORE`, `ON`, `OFF`, `NEVER`.
- `setRedstoneConduitSignalColor(side:number, conduitDirection:number, color:string):boolean`
  Set the redstone conduit signal color at the side facing the conduit direction.
- `setRedstoneConduitSignalStrength(side:number, conduitDirection:number, strength:boolean):boolean`
  Set the redstone conduit signal strength (`true` = strong signal, `false` = weak).
- `replaceConduitFilter(side:number, conduitDirection:number, input:boolean):boolean`
  Replace the item conduit input or output filter with the filter item in the currently selected slot. Robot only.

## Contents
