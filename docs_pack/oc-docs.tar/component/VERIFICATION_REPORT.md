# Component Method Table Verification Report

Date: 2026-08-06

## Summary

Verification of wiki method tables in `wiki/markdown/component/` against the GTNH fork OpenComputers source at `F:/valutGTNH/repos/OpenComputers/src/main`.

- Total components verified: 46
- Components with COMPLETE method tables: 27
- Components with MISSING methods (INCOMPLETE): 15
- Components with ERRORS (documented methods not in source): 4

> Method extraction: wiki methods from `- name(` / `### name(` lines; source methods from `@Callback`-annotated `def name(` (Scala) / `public Object[] name(` (Java), including inherited trait mixins resolved through the class hierarchy. Multi-variant components (adapter/drone/robot/microcontroller) are evaluated as the union of all variants.

## Detailed Findings

### 3d_printer
- Source file(s): common/tileentity/Printer.scala
- Documented methods: 14
- Source methods: 18
- Status: ⚠️ INCOMPLETE
- Missing from wiki (4): getLightLevel, isCollidable, setCollidable, setLightLevel
- Notes: 4 fork-added methods missing (getLightLevel, setLightLevel, isCollidable, setCollidable).

### abstract_bus
- Source file(s): integration/stargatetech2/AbstractBusCard.scala
- Documented methods: 7
- Source methods: 7
- Status: ✅ COMPLETE

### access_point
- Source file(s): common/tileentity/AccessPoint.scala
- Documented methods: 4
- Source methods: 4
- Status: ✅ COMPLETE

### arcane_crafting
- Source file(s): integration/thaumcraft/UpgradeArcaneCrafting.scala
- Documented methods: 3
- Source methods: 3
- Status: ✅ COMPLETE

### barcode_reader
- Source file(s): server/component/UpgradeBarcodeReader.scala
- Documented methods: 0
- Source methods: 0
- Status: ✅ COMPLETE

### beekeeper
- Source file(s): integration/forestry/UpgradeBeekeeper.scala
- Documented methods: 8
- Source methods: 8
- Status: ✅ COMPLETE

### chunkloader
- Source file(s): server/component/UpgradeChunkloader.scala
- Documented methods: 2
- Source methods: 2
- Status: ✅ COMPLETE

### computer
- Source file(s): server/machine/Machine.scala
- Documented methods: 8
- Source methods: 6
- Status: ❌ ERRORS
- Missing from wiki (1): getProgramLocations
- Documented but not in source (3): crash, getArchitecture, isRobot
- Notes: crash/getArchitecture/isRobot were removed from the computer *component* in the GTNH fork; they now live in the Lua `computer` API (server/machine/luac/ComputerAPI.scala, luaj/ComputerAPI.scala). getProgramLocations is a fork addition.

### configurator
- Source file(s): server/component/UpgradeConfigurator.scala
- Documented methods: 15
- Source methods: 15
- Status: ✅ COMPLETE

### crafting
- Source file(s): server/component/UpgradeCrafting.scala
- Documented methods: 1
- Source methods: 1
- Status: ✅ COMPLETE

### data
- Source file(s): server/component/DataCard.scala
- Documented methods: 15
- Source methods: 22
- Status: ⚠️ INCOMPLETE
- Missing from wiki (7): decodeNBT, decodeNBTStr, encodeNBT, encodeNBTStr, isPublic, keyType, serialize
- Notes: 7 fork-added crypto/NBT methods (encodeNBT/decodeNBT/encodeNBTStr/decodeNBTStr/serialize/isPublic/keyType) missing. Wiki covers vanilla methods correctly.

### database
- Source file(s): server/component/UpgradeDatabase.scala
- Documented methods: 6
- Source methods: 7
- Status: ⚠️ INCOMPLETE
- Missing from wiki (1): set
- Notes: `set` is present in fork's UpgradeDatabase but not documented.

### debug
- Source file(s): server/component/DebugCard.scala
- Documented methods: 67
- Source methods: 49
- Status: ❌ ERRORS
- Documented but not in source (18): addExperienceLevel, addObjective, addPlayerToTeam, addTeam, clearInventory, decreasePlayerScore, getBlockState, getExperienceTotal, getLevel, getPlayerScore, getScoreboard, increasePlayerScore, removeExperienceLevel, removeObjective, removePlayerFromTeam, removePlayerFromTeams, removeTeam, setPlayerScore
- Notes: 18 vanilla OC debug methods (scoreboard, player level/experience, getBlockState, clearInventory, etc.) were removed/renamed in the fork. Fork uses MC1.7-era names getBlockId/getMetadata instead of getBlockState. All 49 remaining methods are documented correctly.

### drive
- Source file(s): server/component/Drive.scala; server/component/DiskDriveMountable.scala
- Documented methods: 9
- Source methods: 12
- Status: ⚠️ INCOMPLETE
- Missing from wiki (3): eject, isEmpty, media
- Notes: 3 fork-added methods missing (eject, isEmpty, media).

### drone
- Source file(s): server/component/Drone.scala; server/component/Agent.scala
- Documented methods: 0
- Source methods: 33
- Status: ⚠️ INCOMPLETE
- Missing from wiki (33): compare, compareFluid, compareFluidTo, compareTo, count, detect, drain, drop, fill, getAcceleration, getLightColor, getMaxVelocity, getOffset, getStatusText, getVelocity, inventorySize, move, name, place, select, selectTank, setAcceleration, setLightColor, setStatusText, space, suck, swing, tankCount, tankLevel, tankSpace, transferFluidTo, transferTo, use
- Notes: Wiki page has EMPTY method sections ('### Base Methods', etc.) - none of the 33 fork callbacks are documented.

### eeprom
- Source file(s): server/component/EEPROM.scala
- Documented methods: 10
- Source methods: 10
- Status: ✅ COMPLETE

### experience
- Source file(s): server/component/UpgradeExperience.scala
- Documented methods: 1
- Source methods: 2
- Status: ⚠️ INCOMPLETE
- Missing from wiki (1): consume
- Notes: consume added in fork.

### filesystem
- Source file(s): server/component/FileSystem.scala
- Documented methods: 18
- Source methods: 18
- Status: ✅ COMPLETE

### generator
- Source file(s): server/component/UpgradeGenerator.scala
- Documented methods: 3
- Source methods: 3
- Status: ✅ COMPLETE

### geolyzer
- Source file(s): server/component/Geolyzer.scala
- Documented methods: 6
- Source methods: 7
- Status: ⚠️ INCOMPLETE
- Missing from wiki (1): scanUndergroundFluids
- Notes: scanUndergroundFluids is a fork addition.

### gpu
- Source file(s): server/component/GraphicsCard.scala
- Documented methods: 30
- Source methods: 30
- Status: ✅ COMPLETE

### hologram
- Source file(s): common/tileentity/Hologram.scala
- Documented methods: 11
- Source methods: 16
- Status: ⚠️ INCOMPLETE
- Missing from wiki (5): getDimensions, getTranslation, setRaw, setRotation, setRotationSpeed
- Notes: 5 fork-added methods missing (setRaw, getTranslation, setRotation, setRotationSpeed, getDimensions).

### internet
- Source file(s): server/component/InternetCard.scala
- Documented methods: 10
- Source methods: 10
- Status: ✅ COMPLETE

### inventory_controller
- Source file(s): server/component/UpgradeInventoryController.scala
- Documented methods: 12
- Source methods: 24
- Status: ⚠️ INCOMPLETE
- Missing from wiki (12): areStacksEquivalent, compareStackToDatabase, dropIntoItemInventory, getAllStacks, getInventoryName, getItemInventorySize, getUpgradeContainerTier, getUpgradeContainerType, installUpgrade, isEquivalentTo, setStackDisplayName, suckFromItemInventory
- Notes: 12 fork-added methods missing, incl. upgrade-container management (installUpgrade, getUpgradeContainerTier, getUpgradeContainerType) and item-inventory methods.

### keyboard
- Source file(s): server/component/Keyboard.scala (component `keyboard` IS registered in the fork, but has no `@Callback` methods — it reacts to signals passively)
- Status: N/A — no `keyboard.md` page exists in the wiki

### leash
- Source file(s): server/component/UpgradeLeash.scala
- Documented methods: 2
- Source methods: 2
- Status: ✅ COMPLETE

### microcontroller
- Source file(s): common/tileentity/Microcontroller.scala
- Documented methods: 6
- Source methods: 6
- Status: ✅ COMPLETE

### modem
- Source file(s): server/component/NetworkCard.scala; server/component/WirelessNetworkCard.scala
- Documented methods: 11
- Source methods: 12
- Status: ⚠️ INCOMPLETE
- Missing from wiki (1): isWired
- Notes: isWired added in fork (wired network card).

### motion_sensor
- Source file(s): server/component/MotionSensor.scala
- Documented methods: 2
- Source methods: 2
- Status: ✅ COMPLETE

### navigation
- Source file(s): server/component/UpgradeNavigation.scala
- Documented methods: 4
- Source methods: 4
- Status: ✅ COMPLETE

### netsplitter
- Source file(s): common/tileentity/NetSplitter.scala
- Documented methods: 4
- Source methods: 4
- Status: ✅ COMPLETE

### piston
- Source file(s): server/component/UpgradePiston.scala
- Documented methods: 1
- Source methods: 1
- Status: ✅ COMPLETE

### redstone
- Source file(s): server/component/RedstoneVanilla.scala; server/component/RedstoneBundled.scala; server/component/RedstoneWireless.scala; server/component/RedstoneSignaller.scala
- Documented methods: 14
- Source methods: 14
- Status: ✅ COMPLETE

### redstone_in_motion
- Source file(s): NONE FOUND IN FORK
- Documented methods: 4
- Source methods: 0
- Status: ❌ ERRORS
- Documented but not in source (4): getAnchored, move, setAnchored, simulate
- Notes: The entire `carriage` component does not exist in the GTNH fork source - the Redstone-in-Motion / Remain-in-Motion integration was not carried over. All 4 documented methods are unverifiable/absent.

### relay
- Source file(s): common/tileentity/Relay.scala
- Documented methods: 4
- Source methods: 4
- Status: ✅ COMPLETE

### robot
- Source file(s): server/component/Robot.scala; server/component/Agent.scala
- Documented methods: 0
- Source methods: 28
- Status: ⚠️ INCOMPLETE
- Missing from wiki (28): compare, compareFluid, compareFluidTo, compareTo, count, detect, drain, drop, durability, fill, getLightColor, inventorySize, move, name, place, select, selectTank, setLightColor, space, suck, swing, tankCount, tankLevel, tankSpace, transferFluidTo, transferTo, turn, use
- Notes: Wiki page has EMPTY method sections - none of the 28 fork callbacks are documented.

### screen
- Source file(s): common/component/TextBuffer.scala; common/component/Screen.scala
- Documented methods: 9
- Source methods: 9
- Status: ✅ COMPLETE
- Notes: COMPLETE - fork matches vanilla screen callbacks exactly (incl. touch mode).

### serial_port
- Source file(s): integration/tis3d/SerialInterfaceProviderAdapter.scala
- Documented methods: 3
- Source methods: 3
- Status: ✅ COMPLETE

### sign
- Source file(s): server/component/UpgradeSignInAdapter.scala; server/component/UpgradeSignInRotatable.scala
- Documented methods: 2
- Source methods: 2
- Status: ✅ COMPLETE

### tank_controller
- Source file(s): server/component/UpgradeTankController.scala
- Documented methods: 9
- Source methods: 10
- Status: ⚠️ INCOMPLETE
- Missing from wiki (1): getTankCount
- Notes: getTankCount (from WorldTankAnalytics trait) not documented.

### tps_card
- Source file(s): server/component/TpsCard.scala
- Documented methods: 14
- Source methods: 14
- Status: ✅ COMPLETE

### tractor_beam
- Source file(s): server/component/UpgradeTractorBeam.scala
- Documented methods: 1
- Source methods: 1
- Status: ✅ COMPLETE

### trading
- Source file(s): server/component/UpgradeTrading.scala
- Documented methods: 6
- Source methods: 1
- Status: ❌ ERRORS
- Documented but not in source (5): getInput, getMerchantId, getOutput, isEnabled, trade
- Notes: Fork's UpgradeTrading exposes ONLY getTrades. The 5 other vanilla methods (getInput, getMerchantId, getOutput, isEnabled, trade) were removed in the fork.

### transposer
- Source file(s): server/component/Transposer.scala
- Documented methods: 16
- Source methods: 25
- Status: ⚠️ INCOMPLETE
- Missing from wiki (9): getContainerCapacityInSlot, getContainerLevelInSlot, getFluidInContainerInSlot, getFluidTransferRate, setStackDisplayName, swap, transferFluidBetweenContainers, transferFluidFromContainerToTank, transferFluidFromTankToContainer
- Notes: 9 fork-added container/fluid-transfer methods missing (getFluidTransferRate, setStackDisplayName, swap, transferFluidBetweenContainers, etc.).

### tunnel
- Source file(s): server/component/LinkedCard.scala
- Documented methods: 5
- Source methods: 5
- Status: ✅ COMPLETE

### upgrade_me
- Source file(s): integration/appeng/UpgradeAE.scala
- Documented methods: 5
- Source methods: 37
- Status: ⚠️ INCOMPLETE
- Missing from wiki (32): activeItems, allItems, cancel, finalOutput, getAvgPowerInjection, getAvgPowerUsage, getCpus, getCraftable, getCraftables, getFluidInNetwork, getFluidsInNetwork, getIdlePowerUsage, getItemInNetwork, getItemsInNetwork, getItemsInNetworkById, getMaxStoredPower, getStack, getStoredPower, hasFailed, isActive, isBusy, isCanceled, isComputing, isDone, isFluidEventSubscription, isItemEventSubscription, pendingItems, request, setFluidEventSubscription, setItemEventSubscription, store, storedItems
- Notes: Fork exposes the full AE2 network-control API (32 methods from integration/appeng/NetworkControl.scala) but wiki documents only the 5 basic methods.

### world_sensor
- Source file(s): integration/gc/WorldSensorCard.scala
- Documented methods: 3
- Source methods: 4
- Status: ⚠️ INCOMPLETE
- Missing from wiki (1): hasBreathableAtmosphere
- Notes: hasBreathableAtmosphere is a fork addition (GC world sensor).

## Priority Actions

HIGH (3+ missing methods or many errors):
- `drone` (33 missing, page is empty), `robot` (28 missing, page is empty), `upgrade_me` (32 missing), `debug` (18 errors), `inventory_controller` (12 missing), `transposer` (9 missing), `data` (7 missing), `trading` (5 errors), `hologram` (5 missing), `3d_printer` (4 missing), `redstone_in_motion` (whole component absent), `computer` (3 errors + 1 missing), `drive` (3 missing)

MEDIUM (1-2 missing methods):
- `modem` (isWired), `geolyzer` (scanUndergroundFluids), `world_sensor` (hasBreathableAtmosphere), `tank_controller` (getTankCount), `database` (set), `experience` (consume)

## Methodology Notes

- `keyboard.md` does not exist in the wiki (no page to verify).
- `tank` (UpgradeTank.scala) is not a registered component in the fork and has no @Callback methods; there is no `tank.md` page.
- `netsplitter.md` documents component `net_splitter` (NetSplitter.scala); `tunnel.md` documents the Linked Card component `tunnel` (LinkedCard.scala), not the NetSplitter tunnel.
- `redstone.md` methods are provided by RedstoneVanilla/RedstoneBundled/RedstoneWireless (registered by RedstoneSignaller); fork adds getWakeThreshold/setWakeThreshold.
- Multi-variant components (configurator: 4 variants; tank_controller/inventory_controller: 3 variants; sign: 2 variants) expose different method sets per host; union reported.
