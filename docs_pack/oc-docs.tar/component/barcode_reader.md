# Component: Barcode Reader
This component is provided by the [analyzer](../item/analyzer.md) when it is installed as an upgrade in a computer or tablet. Instead of being used directly, it works passively: when the holder of a [tablet](../item/tablet.md) uses it to scan an OpenComputers block, the barcode reader captures the analyzed nodes (their component type and address) and stores them in the tablet's NBT data, where they can be read back by programs.

Component name: `barcode_reader`.
Callbacks:

This component has no callbacks. It only reacts to `tablet.use` signals generated when the tablet is used on an OpenComputers block.

## Contents
