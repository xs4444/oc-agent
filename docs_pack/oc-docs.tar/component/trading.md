# Component: Trading
This component is provided by trading upgrades

Component name: `trading`.

> **GTNH fork note:** The vanilla OC trading upgrade's per-trade methods (`isEnabled`, `trade`, `getInput`, `getOutput`, `getMerchantId` on the trade userdata objects) were removed in the GTNH fork. The fork's `UpgradeTrading` exposes only the `getTrades` callback below.

Callbacks:

- `getTrades():table`
  Returns a table of trades in range as userdata objects.

---

