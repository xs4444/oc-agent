| [OpenComputers](start.md) |  |  |  |
| --- | --- | --- | --- |
| **Full Index** |  | [Complete Markdown Index](index.md) — 全部 232 页索引 |  |
| General |  | [Install and Use OpenOS](openos.md) - [Crossmod Interoperation](crossmod_interoperation.md) - [Lua Conventions](lua_conventions.md) - [Computer Users](computer_users.md) |  |
| GTNH Guides |  | [GTNH OpenComputers Guides](gtnh/contents.md) — [Overview](gtnh/open_computers.md) - [Cross-Mod Integration](gtnh/crossmod_integration.md)（25 模组分文件） - [AR Glasses](gtnh/ar_glasses.md) - [NIDAS](gtnh/nidas.md) - [Power Display](gtnh/power_display.md) - [Item Stocking](gtnh/item_stocking.md) - [Crop Breeding](gtnh/crop_breeding.md) - [Space Pumping](gtnh/space_pumping.md) |  |
| Addons |  | [Addon Mods](addon.md) |  |

| Other Languages |  | [简体中文（Simplified Chinese）](start_zh.md) |
| --- | --- | --- |
