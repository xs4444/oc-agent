# RAID
The RAID is a storage array block with three disk drive bays. When three [hard disk drives](../item/hard_disk_drive.md) are installed, it combines them into a single virtual RAID filesystem, pooling their storage space. The filesystem is exposed on the network like a regular drive and can be used by adjacent computers and other network devices.

The RAID is rotatable and provides a GUI (right-click to open) for inserting and removing hard drives. When a drive is added or removed the RAID filesystem is re-created, wiping the disks, so the RAID is best used as a permanent, dedicated storage array. The RAID has a comparator output that emits a signal of strength 15 when all three bays are occupied.

When the RAID is broken, its contents (the installed disks and filesystem) are preserved on the dropped item, so the whole array can be picked up and relocated.

## Contents
