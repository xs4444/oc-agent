# Transposer



The transposer bridges the gap between redstone controlled hoppers and [Robot](robot.md), allowing [computer](computer_case.md)-controlled transferal of items and fluids between adjacent blocks.

*Note that this block has no internal inventory.*

Besides moving things around, it can also be used to inspect the contents of the adjacent inventories, like an [Adapter](adapter.md) with an [inventory controller](../component/inventory_controller.md) could, and the contents of adjacent tanks, like and adapter with a [Tank Controller](../component/tank_controller.md) could.

The transposer can also interactive with player inventory when player stands next to or on it.

The component proxy on a computer provides an api as described [here](../component/transposer.md)
