# Relay
The Relay is a wireless network block that extends the range of OpenComputers wireless networks. Like a [switch](switch.md) it connects adjacent wired networks, but it also joins the wireless network and re-sends received wireless packets, effectively acting as a wireless range extender and repeater.

To use its wireless features, open the Relay GUI and insert a [Wireless Network Card](../item/wireless_network_card.md) (tier 1 or 2) or a [Linked Card](../item/linked_card.md) into its card slot. The wireless range is determined by the tier of the installed wireless network card; with a linked card the relay instead forwards packets over a quantum tunnel. The signal strength (range) used when relaying and whether the relay acts as a wireless repeater can be controlled from a computer via the [relay component](../component/relay.md).

Like the switch, relays have a limited wired bandwidth. The packet relay rate, packets per cycle and internal queue size can be increased by installing a CPU, RAM or hard disk drive into the relay.

The Relay requires power to operate. Relaying wireless packets consumes energy proportional to the configured signal strength and the wireless cost per range.

The Relay is obtained by converting an existing [Access Point](access_point.md) or [Switch](switch.md) in a shapeless crafting recipe.

## Contents
