# OpenComputers Wiki — Markdown Index

Complete index of all pages under `markdown/`. **232 content pages** (+ navigation/hub pages).

> Part of the [GTNH OpenComputers offline documentation](../README.md)

### Navigation & Hub Pages

- [Addon](addon.md)
- [Addons](addons.md)
- [Api](api.md)
- [Apis](apis.md)
- [Basic Commands](basic_commands.md)
- [Chinese Page](chinese_page.md)
- [Component](component.md)
- [Components](components.md)
- [Computer Users](computer_users.md)
- [Computer Users Zh](computer_users_zh.md)
- [Contents](contents.md)
- [Contents Zh](contents_zh.md)
- [Crossmod Interoperation](crossmod_interoperation.md)
- [Crossmod Interoperation Zh](crossmod_interoperation_zh.md)
- [Imc](imc.md)
- [Lua Conventions](lua_conventions.md)
- [Lua Conventions Zh](lua_conventions_zh.md)
- [Onethree](onethree.md)
- [Openos](openos.md)
- [Openos Zh](openos_zh.md)
- [Start](start.md)
- [Start Zh](start_zh.md)
- [Test Event.listen](test_event.listen.md)
- [Tutorial](tutorial.md)
- [Tutorials](tutorials.md)

### block/ (31 pages)

Index pages: [contents](block/contents.md)

| Page | Title |
| --- | --- |
| [3d_printer](block/3d_printer.md) | 3D Printer |
| [access_point](block/access_point.md) | Access Point |
| [adapter](block/adapter.md) | Adapter |
| [assembler](block/assembler.md) | Assembler |
| [cable](block/cable.md) | Cable |
| [capacitor](block/capacitor.md) | Capacitor |
| [carpeted_capacitor](block/carpeted_capacitor.md) | Carpeted Capacitor |
| [case](block/case.md) | Case |
| [charger](block/charger.md) | Charger |
| [computer_case](block/computer_case.md) | Computer Case |
| [disassembler](block/disassembler.md) | Disassembler |
| [disk_drive](block/disk_drive.md) | Disk Drive |
| [geolyzer](block/geolyzer.md) | Geolyzer |
| [hologram](block/hologram.md) | Hologram |
| [hologram_projector](block/hologram_projector.md) | Hologram Projector |
| [keyboard](block/keyboard.md) | Keyboard |
| [microcontroller](block/microcontroller.md) | Microcontroller |
| [motion_sensor](block/motion_sensor.md) | Motion Sensor |
| [net_splitter](block/net_splitter.md) | Net Splitter |
| [power_converter](block/power_converter.md) | Power Converter |
| [power_distributor](block/power_distributor.md) | Power Distributor |
| [rack](block/rack.md) | Rack |
| [raid](block/raid.md) | RAID |
| [redstone_io](block/redstone_io.md) | Redstone I/O |
| [relay](block/relay.md) | Relay |
| [robot](block/robot.md) | Robot |
| [screen](block/screen.md) | Screen |
| [server_rack](block/server_rack.md) | Server Rack |
| [switch](block/switch.md) | Relay |
| [transposer](block/transposer.md) | Transposer |
| [waypoint](block/waypoint.md) | Waypoint |

### item/ (75 pages)

Index pages: [contents](item/contents.md)

| Page | Title |
| --- | --- |
| [abstract_bus_card](item/abstract_bus_card.md) | Abstract Bus Card |
| [analyzer](item/analyzer.md) | Analyzer |
| [angel_upgrade](item/angel_upgrade.md) | Angel Upgrade |
| [apu](item/apu.md) | Apu |
| [battery_upgrade](item/battery_upgrade.md) | Battery Upgrade |
| [card_container](item/card_container.md) | Card Container |
| [chunkloader_upgrade](item/chunkloader_upgrade.md) | Chunkloader Upgrade |
| [component_bus](item/component_bus.md) | Component Bus |
| [cpu](item/cpu.md) | Cpu |
| [crafting](item/crafting.md) | Crafting |
| [crafting_items](item/crafting_items.md) | Crafting Items |
| [crafting_upgrade](item/crafting_upgrade.md) | Crafting Upgrade |
| [data_card](item/data_card.md) | Data Card |
| [database_upgrade](item/database_upgrade.md) | Database Upgrade |
| [debug_card](item/debug_card.md) | Debug Card |
| [debugger](item/debugger.md) | Network Debugger |
| [default_vendor](item/default_vendor.md) | Default Vendor |
| [disk_drive_mountable](item/disk_drive_mountable.md) | Mountable Disk Drive |
| [drone](item/drone.md) | Drone |
| [dronecase](item/dronecase.md) | Drone Case |
| [eeprom](item/eeprom.md) | EEPROM |
| [expansion_card](item/expansion_card.md) | Expansion Cards |
| [experience_upgrade](item/experience_upgrade.md) | Experience Upgrade |
| [floppy](item/floppy.md) | Floppy |
| [floppy_disk](item/floppy_disk.md) | Floppy Disk |
| [generator_upgrade](item/generator_upgrade.md) | Generator Upgrade |
| [gpu](item/gpu.md) | Gpu |
| [graphics_card](item/graphics_card.md) | Graphics Card |
| [grog](item/grog.md) | Grog |
| [hard_disk_drive](item/hard_disk_drive.md) | Hard Disk Drive |
| [hdd](item/hdd.md) | Hdd |
| [hover_boots](item/hover_boots.md) | Hover Boots |
| [hover_upgrade](item/hover_upgrade.md) | Hover Upgrade |
| [ink_cartridge](item/ink_cartridge.md) | Ink Cartridge |
| [internet_card](item/internet_card.md) | Internet Card |
| [inventory_controller_upgrade](item/inventory_controller_upgrade.md) | Inventory Controller Upgrade |
| [inventory_upgrade](item/inventory_upgrade.md) | Inventory Upgrade |
| [lan_card](item/lan_card.md) | Lan Card |
| [leash_upgrade](item/leash_upgrade.md) | Leash Upgrade |
| [linked_card](item/linked_card.md) | Linked Card |
| [loot_disks](item/loot_disks.md) | Loot Disks |
| [manual](item/manual.md) | OpenComputers Manual |
| [materials](item/materials.md) | Crafting Materials |
| [memory](item/memory.md) | Memory |
| [mfu](item/mfu.md) | MFU |
| [microcontrollercase](item/microcontrollercase.md) | Microcontroller Case |
| [nanomachines](item/nanomachines.md) | Nanomachines |
| [navigation_upgrade](item/navigation_upgrade.md) | Navigation Upgrade |
| [network_card](item/network_card.md) | Network Card |
| [openos_floppy](item/openos_floppy.md) | OpenOS Floppy Disk |
| [piston_upgrade](item/piston_upgrade.md) | Piston Upgrade |
| [present](item/present.md) | Present |
| [processor](item/processor.md) | Processor |
| [ram](item/ram.md) | Ram |
| [redstone_card](item/redstone_card.md) | Redstone Card |
| [scrench](item/scrench.md) | Scrench |
| [scummtech](item/scummtech.md) | Scummtech |
| [server](item/server.md) | Server |
| [sign_upgrade](item/sign_upgrade.md) | Sign I/O Upgrade |
| [solar_generator_upgrade](item/solar_generator_upgrade.md) | Solar Generator Upgrade |
| [tablet](item/tablet.md) | Tablet |
| [tablet_case](item/tablet_case.md) | Tablet Case |
| [tank_controller_upgrade](item/tank_controller_upgrade.md) | Tank Controller Upgrade |
| [tank_upgrade](item/tank_upgrade.md) | Tank Upgrade |
| [terminal](item/terminal.md) | Remote Terminal |
| [terminal_server](item/terminal_server.md) | Terminal Server |
| [texture_picker](item/texture_picker.md) | Texture Picker |
| [tps_card](item/tps_card.md) | TPS Card |
| [tractor_beam_upgrade](item/tractor_beam_upgrade.md) | Tractor Beam Upgrade |
| [trading_upgrade](item/trading_upgrade.md) | Trading Upgrade |
| [upgrade_ae](item/upgrade_ae.md) | ME Upgrade |
| [upgrade_container](item/upgrade_container.md) | Upgrade Container |
| [wireless_network_card](item/wireless_network_card.md) | Wireless Network Card |
| [wlan_card](item/wlan_card.md) | Wlan Card |
| [world_sensor_upgrade](item/world_sensor_upgrade.md) | World Sensor Upgrade |

### component/ (54 pages)

Index pages: [contents](component/contents.md) · [zh](component/zh.md)

| Page | Title |
| --- | --- |
| [3d_printer](component/3d_printer.md) | 3D Printer |
| [VERIFICATION_REPORT](component/VERIFICATION_REPORT.md) | Component Method Table Verification Report |
| [abstract_bus](component/abstract_bus.md) | Component: Abstract Bus |
| [access_point](component/access_point.md) | Component: Access Point |
| [ae2common](component/ae2common.md) | Ae2Common |
| [agent](component/agent.md) | Agent |
| [applied_energistics](component/applied_energistics.md) | Components: Applied Energistics |
| [arcane_crafting](component/arcane_crafting.md) | Component: Arcane Crafting Upgrade |
| [barcode_reader](component/barcode_reader.md) | Component: Barcode Reader |
| [beekeeper](component/beekeeper.md) | Component: Beekeeper Upgrade |
| [chunkloader](component/chunkloader.md) | Component: Chunkloader |
| [component_access](component/component_access.md) | Component Access |
| [computer](component/computer.md) | Component: Computer |
| [configurator](component/configurator.md) | Component: Configurator |
| [crafting](component/crafting.md) | Component: Crafting |
| [data](component/data.md) | Component: Data |
| [database](component/database.md) | Component: Database |
| [debug](component/debug.md) | Component: Debug |
| [drive](component/drive.md) | Component: Drive |
| [drone](component/drone.md) | Component: Drone |
| [eeprom](component/eeprom.md) | Component: EEPROM |
| [experience](component/experience.md) | Component: Experience |
| [filesystem](component/filesystem.md) | Component: Filesystem |
| [generator](component/generator.md) | Component: Generator |
| [geolyzer](component/geolyzer.md) | Component: Geolyzer |
| [gpu](component/gpu.md) | Component: GPU |
| [hologram](component/hologram.md) | Component: Hologram |
| [internet](component/internet.md) | Component: Internet |
| [inventory_controller](component/inventory_controller.md) | Component: Inventory Controller |
| [inventory_slots](component/inventory_slots.md) | Inventory Slots |
| [keyboard](component/keyboard.md) | Component: Keyboard |
| [leash](component/leash.md) | Leash Upgrade |
| [microcontroller](component/microcontroller.md) | Component: Microcontroller |
| [modem](component/modem.md) | Component: Modem |
| [motion_sensor](component/motion_sensor.md) | Component: Motion Sensor |
| [navigation](component/navigation.md) | Component: Navigation |
| [netsplitter](component/netsplitter.md) | Component: Net Splitter |
| [piston](component/piston.md) | Component: Piston |
| [redstone](component/redstone.md) | Component: Redstone |
| [redstone_in_motion](component/redstone_in_motion.md) | Redstone In Motion |
| [relay](component/relay.md) | Component: Relay |
| [robot](component/robot.md) | Component: Robot |
| [screen](component/screen.md) | Component: Screen |
| [serial_port](component/serial_port.md) | Component: Serial Port |
| [sign](component/sign.md) | Component: Sign |
| [signals](component/signals.md) | Signals |
| [tank_controller](component/tank_controller.md) | Component: Tank Controller |
| [tps_card](component/tps_card.md) | Component: TPS Card |
| [tractor_beam](component/tractor_beam.md) | Component: Tractor Beam |
| [trading](component/trading.md) | Component: Trading |
| [transposer](component/transposer.md) | Component: Transposer |
| [tunnel](component/tunnel.md) | Component: Tunnel |
| [upgrade_me](component/upgrade_me.md) | Component: ME Upgrade |
| [world_sensor](component/world_sensor.md) | World Sensor |

### api/ (25 pages)

Index pages: [contents](api/contents.md) · [zh](api/zh.md)

| Page | Title |
| --- | --- |
| [buffer](api/buffer.md) | Buffer API |
| [colors](api/colors.md) | Colors API |
| [colours](api/colours.md) | Colours |
| [component](api/component.md) | Component API |
| [computer](api/computer.md) | Computer API |
| [event](api/event.md) | Event API |
| [filesystem](api/filesystem.md) | Filesystem API |
| [guid](api/guid.md) | Guid |
| [internet](api/internet.md) | Internet API |
| [keyboard](api/keyboard.md) | Keyboard API |
| [nbt](api/nbt.md) | NBT API |
| [non-standard-lua-libs](api/non-standard-lua-libs.md) | Non-standard Lua Libraries |
| [note](api/note.md) | Note API |
| [process](api/process.md) | Process API |
| [rc](api/rc.md) | RC API |
| [robot](api/robot.md) | Robot API |
| [serialization](api/serialization.md) | Serialization API |
| [shell](api/shell.md) | Shell API |
| [sides](api/sides.md) | Sides API |
| [term](api/term.md) | Term API |
| [text](api/text.md) | Text API |
| [thread](api/thread.md) | Thread API |
| [transforms](api/transforms.md) | Transforms |
| [unicode](api/unicode.md) | Unicode API |
| [uuid](api/uuid.md) | Uuid |

### addon/ (1 pages)

Index pages: [contents](addon/contents.md) · [zh](addon/zh.md)

| Page | Title |
| --- | --- |
| [thutconcrete](addon/thutconcrete.md) | Thut's Concrete |

### tutorial/ (13 pages)

Index pages: [contents](tutorial/contents.md) · [zh](tutorial/zh.md)

| Page | Title |
| --- | --- |
| [autorun_options](tutorial/autorun_options.md) | Custom Startup Programs |
| [custom_oses](tutorial/custom_oses.md) | Writing custom OSes |
| [debug_1.7.10](tutorial/debug_1.7.10.md) | Steps to Build and Run master-MC1.7.10 from source |
| [modding_architecture](tutorial/modding_architecture.md) | Modding: Custom Architectures |
| [modding_imc](tutorial/modding_imc.md) | Modding Imc |
| [modding_onefour](tutorial/modding_onefour.md) | API changes in OpenComputers v1.4 |
| [modding_onethree](tutorial/modding_onethree.md) | Blocks / Items API |
| [oc1_basic_computer](tutorial/oc1_basic_computer.md) | OC Tutorial: Basic Computer |
| [oc2_writing_code](tutorial/oc2_writing_code.md) | OC Tutorial: Writing Code |
| [oc3_hard_drives](tutorial/oc3_hard_drives.md) | OC Tutorial: Hard Drives |
| [program_install](tutorial/program_install.md) | Tutorial: The Install Program |
| [program_oppm](tutorial/program_oppm.md) | Tutorial: The OpenPrograms Package Manager (OPPM) |
| [translate_rule](tutorial/translate_rule.md) | 翻译规则 |

### gtnh/ (8 pages)

Index pages: [contents](gtnh/contents.md)

| Page | Title |
| --- | --- |
| [ar_glasses](gtnh/ar_glasses.md) | AR Glasses |
| [crop_breeding](gtnh/crop_breeding.md) | OpenComputers Crop Breeding |
| [crossmod_integration](gtnh/crossmod_integration.md) | GTNH Cross-Mod Integration |
| [item_stocking](gtnh/item_stocking.md) | OpenComputers Item Stocking |
| [nidas](gtnh/nidas.md) | NIDAS |
| [open_computers](gtnh/open_computers.md) | OpenComputers (GTNH) |
| [power_display](gtnh/power_display.md) | OpenComputers Power Display |
| [space_pumping](gtnh/space_pumping.md) | OpenComputers Space Pumping |

### gtnh/mods/ (25 pages)

| Page | Title |
| --- | --- |
| [ae2](gtnh/mods/ae2.md) | Applied Energistics 2 — OC Integration |
| [ae2_fluid_craft](gtnh/mods/ae2_fluid_craft.md) | AE2 Fluid Craft — OC Integration |
| [asielib](gtnh/mods/asielib.md) | AsieLib — OC Integration |
| [blood_magic](gtnh/mods/blood_magic.md) | Blood Magic — OC Integration |
| [computronics](gtnh/mods/computronics.md) | Computronics — OC Integration |
| [display_panels](gtnh/mods/display_panels.md) | Display Panels / Nuclear Control 2 — OC Integration |
| [draconic_evolution](gtnh/mods/draconic_evolution.md) | Draconic Evolution — OC Integration |
| [enderio](gtnh/mods/enderio.md) | EnderIO — OC Integration |
| [enhanced_lootbags](gtnh/mods/enhanced_lootbags.md) | Enhanced Lootbags — OC Integration |
| [forestry](gtnh/mods/forestry.md) | Forestry — OC Integration |
| [forge_of_the_gods](gtnh/mods/forge_of_the_gods.md) | Forge of the Gods — OC Integration |
| [gregtech](gtnh/mods/gregtech.md) | GregTech — OC Integration |
| [ic2](gtnh/mods/ic2.md) | IndustrialCraft 2 — OC Integration |
| [logistics_pipes](gtnh/mods/logistics_pipes.md) | Logistics Pipes — OC Integration |
| [matter_manipulator](gtnh/mods/matter_manipulator.md) | MatterManipulator — OC Integration |
| [ocglasses](gtnh/mods/ocglasses.md) | OCGlasses (AR Glasses) — OC Integration |
| [open_modular_turrets](gtnh/mods/open_modular_turrets.md) | OpenModularTurrets — OC Integration |
| [openprinter](gtnh/mods/openprinter.md) | OpenPrinter — OC Integration |
| [opensecurity](gtnh/mods/opensecurity.md) | OpenSecurity — OC Integration |
| [random_things](gtnh/mods/random_things.md) | Random Things — OC Integration |
| [sgcraft](gtnh/mods/sgcraft.md) | Stargate / SGCraft — OC Integration |
| [thaumcraft](gtnh/mods/thaumcraft.md) | Thaumcraft — OC Integration |
| [thaumic_energistics](gtnh/mods/thaumic_energistics.md) | Thaumic Energistics — OC Integration |
| [thaumic_tinkerer](gtnh/mods/thaumic_tinkerer.md) | ThaumicTinkerer — OC Integration |
| [vanilla](gtnh/mods/vanilla.md) | Vanilla Minecraft — OC Integration |
